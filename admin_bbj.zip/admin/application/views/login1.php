<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/favicon.png">
  <title>Welcome / MLM Admin</title>

  
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/open-sans/style.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/iconfont/iconfont.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/flatpickr/flatpickr.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/tippyjs/tippy.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/select2/css/select2.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.min.css" id="stylesheet">

  

  <script src="<?php echo base_url(); ?>assets/js/ie.assign.fix.min.js"></script>
</head>
<body class="p-front p-signup-helper">

<div class="preloader">
  <div class="loader">
    <span class="loader__indicator"></span>
    <div class="loader__label"><img src="<?php echo base_url(); ?>assets/img/logo.png" alt=""></div>
  </div>
</div>


<div class="navbar navbar-light navbar-expand-lg p-front__navbar"> <!-- is-dark -->
  <a class="navbar-brand" href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/img/logo.png" alt=""/></a>
  <a class="navbar-brand-sm" href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/img/logo-sm.png" alt=""/></a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-collapse">
    <span class="iconfont iconfont-navbar-open navbar-toggler__open"></span>
    <span class="iconfont iconfont-alert-close navbar-toggler__close"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbar-collapse">
    <div class="p-front__navbar-collapse">
      <div class="navbar-nav">
        <a class="nav-item nav-link active" href="<?php echo base_url(); ?>assets/#">About</a>
        <a class="nav-item nav-link" href="<?php echo base_url(); ?>assets/#">Features</a>
        <a class="nav-item nav-link" href="<?php echo base_url(); ?>assets/#">Pricing</a>
      </div>
      <form method="post" class="form-inline">
        <input class="form-control mr-lg-3" type="email" name="email" placeholder="Email">
        <input class="form-control mr-lg-4" type="password" placeholder="Password">
        <button type="submit"  name="submit" class="btn btn-info" >Login In</button>
      </form>
    </div>
  </div>
</div>


<div class="p-front__content">
  
<div class="p-signup-a">
  <h1>welcome to Gold beauty</h1>
  <!-- <img src="<?php echo base_url(); ?>assets/img/signup/01.png" alt="" class="p-signup-a__image"> -->

<!--   <div class="p-signup-a__wrap">
    <form class="p-signup-a__form">
      <h4 class="p-signup-a__form-heading">Free Registration</h4>
      <div class="form-group">
        <input type="text" class="form-control" name="data[name]" placeholder="Full Name"  required >
      </div>
      <div class="form-group">
        <input  type="text" class="form-control" placeholder="Username"  pattern="[a-z]{1}[0-9a-z_]{4,20}"  name="data[username]"  required >
      </div>
      <div class="form-group">
        <input type="password" class="form-control" name="data[password]"  placeholder="Password"  required >
      </div>
      <div class="form-group">
        <input type="text" class="form-control"  pattern="[0-9]{10,12}"  placeholder="Mobile Number" name="data[phone]" required  >
      </div>
      <div class="form-group">
        <input type="email" class="form-control" placeholder="Email" name="data[email]" >
      </div>
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Sponserid" name="data[sponserid]" >
      </div>

      <div class="form-group text-center">
        <button type="submit" class="btn btn-info btn-lg p-signup-a__form-submit">Register</button>
      <span class="p-signup-a__form-terms">
        By signing up, you agree to our <a href="<?php echo base_url(); ?>assets/#" class="p-signup-a__form-terms-link">Terms</a> &amp; <a href="<?php echo base_url(); ?>assets/#" class="p-signup-a__form-terms-link">Privacy Policy</a>
      </span>
      </div>
    </form>
<!--     <div class="p-signup-a__app-install">
      <a href="<?php echo base_url(); ?>assets/#"><img src="<?php echo base_url(); ?>assets/img/signup/02.png" alt=""></a>
      <a href="<?php echo base_url(); ?>assets/#"><img src="<?php echo base_url(); ?>assets/img/signup/03.png" alt=""></a>
    </div>
  </div> -->
</div>

</div>


<footer class="p-front__footer">
  <ul class="nav">
    <li class="nav-item">
      <a class="nav-link active" href="<?php echo base_url(); ?>assets/#">About Us</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo base_url(); ?>assets/#">Support</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo base_url(); ?>assets/#">Privacy</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo base_url(); ?>assets/#">Terms</a>
    </li>
  </ul>
  <span>2017 &copy; Glod Beauty Admin</span>
</footer>



  <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/popper/popper.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/simplebar/simplebar.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/text-avatar/jquery.textavatar.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/tippyjs/tippy.all.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/flatpickr/flatpickr.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/wnumb/wNumb.js"></script>
<script src="<?php echo base_url(); ?>assets/js/main.js"></script>



<div class="sidebar-mobile-overlay"></div>

</body>

</html>
