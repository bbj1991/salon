
    
<div class="container-fluid">
<!--   <div class="page-content__header">
    <div>
      <h2 class="page-content__header-heading">Services</h2>
    </div>
  </div> -->
  <div class="main-container">
    <h3>Services</h3>
    <div class="row">
      <div class="col-3">
        <h4>Input</h4>
        <div class="form-group">
          <input type="text" placeholder="Favorite NBA Team" class="form-control">
        </div>
        <div class="form-group">
          <label for="disabled">Disabled</label>
          <input id="disabled" type="text" placeholder="Favorite NBA Team" class="form-control" disabled>
        </div>
      </div>
      <div class="col-3">
        <h4>Input with label</h4>
        <div class="form-group">
          <input type="text" placeholder="Favorite NBA Team" class="form-control">
        </div>
        <div class="form-group">
          <label for="read-only">Read Only</label>
          <input id="read-only" type="text" placeholder="Favorite NBA Team" class="form-control" readonly>
        </div>
      </div>
      <div class="col-6">
        <h4>Textarea</h4>
        <div class="form-group">
          <textarea rows="3" placeholder="Favorite NBA Team" class="form-control"></textarea>
        </div>
      </div>
    </div>
  </div>
  <div class="main-container">
    
  </div>
</div>

  