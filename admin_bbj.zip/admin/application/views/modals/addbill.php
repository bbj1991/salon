
    
<h3>New Billing</h3>
<hr>
    <div class="row" id="fc"></div>
<hr>
        <div>
          <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab" aria-controls="home" aria-expanded="true">ADD Service</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="tab" href="#tab2" role="tab" aria-controls="profile" aria-expanded="false">ADD Product</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="tab" href="#tab3" role="tab" aria-controls="messages">ADD Package</a>
            </li>
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab1" role="tabpanel" aria-expanded="true">  
                  <div class="row">
            
      
            <div class="col-5">
              <div class="form-group">
              <span>service : </span> <select class="form-control selectbox " id="sid">
 <?php $br=$this->db->get_where('service',array('status'=>1))->result(); foreach ($br as $v) {?>
                                         <option value="<?php echo $v->id; ?>"><?php echo $v->name; ?></option>
                                        <?php } ?>
                                      </select>
                                  </div>
                              </div>
      <div class="col-2">
        <div class="form-group">
         <span>Quantity : </span> <input type="number" value="1" class="form-control" id="sqty">
        </div>

      </div>
      <div class="col-3">
        <a class="btn btn-primary" onclick="addservice();" style="margin-top: 22px;">ADD Service</a>
      </div>
      
</div>
</div>
            <div class="tab-pane" id="tab2" role="tabpanel" aria-expanded="false">
               <div class="row">

      
            <div class="col-5">
              <div class="form-group">
              <span>Product : </span> <select class="form-control selectbox " id="pid">
                                         <?php $br=$this->db->get_where('product',array('status'=>1))->result(); foreach ($br as $v) {?>
                                         <option value="<?php echo $v->id; ?>"><?php echo $v->name; ?></option>
                                        <?php } ?>
                                      </select>
                                  </div>
                              </div>
      <div class="col-2">
        <div class="form-group">
         <span>Quantity : </span> <input type="number" value="1" class="form-control" id="pqty">
        </div>

      </div>
      <div class="col-3">
        <a class="btn btn-primary" onclick="addproduct();" style="margin-top: 22px;">ADD Product</a>
      </div>
      
</div></div>
            <div class="tab-pane" id="tab3" role="tabpanel">
                      <div class="row">

      
            <div class="col-5">
              <div class="form-group">
              <span>Package : </span> <select class="form-control selectbox " id="pkid">
                                         <?php $br=$this->db->get_where('package',array('status'=>1))->result(); foreach ($br as $v) {?>
                                         <option value="<?php echo $v->id; ?>"><?php echo $v->name; ?></option>
                                        <?php } ?>
                                      </select>
                                  </div>
                              </div>
                                    <div class="col-2">
        <div class="form-group">
         <span>Quantity : </span> <input type="number" value="1" class="form-control" id="pkqty">
        </div>

      </div>

      <div class="col-3">
        <a class="btn btn-primary" onclick="addpackage();" style="margin-top: 22px;">ADD Package</a>
      </div>
      
</div>
            </div>
          </div>
        </div>
   <hr>

<div class="main-container">
<form method="post" enctype="multipart/form-data">

    <div class="row">
      <div class="col-lg-12">

          <input type="hidden" name="customer" value="<?php echo $id ?>" required>
        <table class="table p-invoice__items table-responsive-sm">
          <thead>
            <tr>
              <th>Unit</th>
              <th>QTY</th>
              <th>Rate</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody id="tbody">
          </tbody>
        </table>
      </div>
    </div>

    <div class="p-invoice__footer">
      <div class="p-invoice__notes">
      <!--   <h6 class="p-invoice__notes-heading">Notes</h6>
        <ul class="p-invoice__notes-list">
          <li>Terms and conditions</li>
          <li>Accounting number: 1234567890</li>
          <li>Routing number: 9876543210</li>
        </ul>
        <div class="mt-4">Thank you for number business!</div> -->
      </div>
      <div class="p-invoice__total">
        <table class="table table-responsive-sm">
          <tr>
            <td><span class="text-muted-md">Subtotal:</span></td>
            <td><input type="text" name="data[amount]" id="amount" readonly class="form-control"></td>
          </tr>
          <tr>
            <td><span class="text-muted-md">Discount:</span></td>
            <td><input type="number" name="data[discount]" id="dis" class="form-control" value="0" onchange="test();"></td>
          </tr>
          <tr class="p-invoice__total-row">
            <td><span class="text-muted-md">Total:</span></td>
            <td><span class="p-invoice__total-amount"><input type="text" readonly name="data[total]" id="total" class="form-control"></span></td>
          </tr>
        </table>
      </div>

    
  </div>

 <div class="row">
      <div class="col-12">
        <h4>Details</h4>
        <div class="form-group">
          <textarea rows="3" placeholder="" class="form-control" name="data[details]"></textarea>
        </div>
      </div>
      </div>

 <div class="row">
     <div class="col-12">
          <div class="form-actions">
             <div class="form-group">
               <div class="btn-list">
                    <button type="submit" name="add_bill" class="btn btn-primary">Submit</button>
                                                      
                         </div>
                                                    
                                </div>
                                               
                       </div>
                                          
               </div>
                                       
        </div>
      </form>

</div>

  
  <script type="text/javascript">
    function addservice() {
      var id=$('#sid').val();
      if($('#srv'+id).val()){
        alert("service already added");
      }else{
      var qty=$('#sqty').val();
          $.post("<?php echo base_url('customer/getservice'); ?>/"+id+"/"+qty, function(data, status){
 $('#tbody').append(data);
 total();
    });
        }
    }
  </script>

  <script type="text/javascript">
    function addproduct() {
      var id=$('#pid').val();
      if($('#prd'+id).val()){
        alert("product already added");
      }else{
      var qty=$('#pqty').val();
          $.post("<?php echo base_url('customer/getproduct'); ?>/"+id+"/"+qty, function(data, status){
 $('#tbody').append(data);
 total() ;
    });
        }
    }

      </script>


  <script type="text/javascript">
    function addpackage() {
      var id=$('#pkid').val();
      if($('#pkg'+id).val()){
        alert("Package already added");
      }else{
      var qty=$('#pkqty').val();
          $.post("<?php echo base_url('customer/getpackage'); ?>/"+id+"/"+qty, function(data, status){
 $('#tbody').append(data);
 total();
    });
        }
    }
      </script>


  <script type="text/javascript">
    function total() {
     var amt=0;  
     $('.samts').each(function () {
      var samt=$(this).val();
      amt=parseInt(amt)+parseInt(samt);

    });
      $('.pamts').each(function () {
      var samt=$(this).val();
      amt=parseInt(amt)+parseInt(samt);
    });
       $('.pkamts').each(function () {
      var samt=$(this).val();
      amt=parseInt(amt)+parseInt(samt);
    });
     $('#amount').val(amt);
     var dis=$('#dis').val();
     $('#total').val(parseInt(amt)-parseInt(dis));
    }
    function test() {
      total();
    }
    function chkcust(id) {
       if(id){
        $.post("<?php echo base_url('customer/getview'); ?>/"+id, function(data, status){
       $('#fc').html(data);
       });
    }
    
  }
  chkcust(<?php echo $id; ?>);
  </script>  