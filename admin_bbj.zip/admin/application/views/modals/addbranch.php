
<div class="main-container">
<h3>Add branch</h3>
<form method="post" enctype="multipart/form-data">
<div class="row">
      <div class="col-4">
        <h4>Name</h4>
        <div class="form-group">
          <input type="text" placeholder="" class="form-control" name="data[name]" required>
        </div>
      </div>
      <div class="col-4">
        <h4>Email</h4>
        <div class="form-group">
          <input type="email" placeholder="" class="form-control" name="data[email]" required>
        </div>
      </div>
        <div class="col-4">
        <h4>Phone</h4>
        <div class="form-group">
          <input type="text" placeholder="" class="form-control" name="data[phone]" required>
        </div>
      </div>
       <div class="col-4">
        <h4>Contact</h4>
        <div class="form-group">
          <input type="text" placeholder="" class="form-control" name="data[contact]" required>
        </div>
      </div>
       <div class="col-4">
        <h4>Alt phone</h4>
        <div class="form-group">
          <input type="text" placeholder="" class="form-control" name="data[altphone]" required>
        </div>
      </div>
       <div class="col-6">
        <h4>Address</h4>
        <div class="form-group">
            <textarea rows="3" placeholder="" class="form-control" name="data[address]" required></textarea>
        </div>
      </div>
      <div class="col-6">
        <h4>Details</h4>
        <div class="form-group">
          <textarea rows="3" placeholder="" class="form-control" name="data[details]"></textarea>
        </div>
      </div>
    </div>
 <div class="row">
     <div class="col-12">
          <div class="form-actions">
             <div class="form-group">
               <div class="btn-list">
                    <button type="submit" name="add_branch" class="btn btn-primary">Submit</button>
                                                      
                         </div>
                                                    
                                </div>
                                               
                       </div>
                                          
               </div>
                                       
        </div>
      </form>

</div>

