          <h5 align="center" class="modal-title">Update Branch details</h5>
            <hr>
            <form method="post" enctype="">
                                 <div class="row">
                                       
                                         <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label"> Name</label>
                                                <input type="text" id="sample5FirstName" class="form-control"   required name="data[name]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">Email</label>
                                                <input type="text" id="sample5FirstName" class="form-control"   required name="data[email]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                         <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label"> Password</label>
                                                <input type="password" id="sample5FirstName" class="form-control"   required name="data[password]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    
                                
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">Phone</label>
                                                <input type="text" id="sample5FirstName" class="form-control"   required name="data[phone]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                         <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label"> address</label>
                                                <input type="text" id="sample5FirstName" class="form-control"   required name="data[address]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-actions">
                                                <div class="form-group">
                                                    <div class="btn-list">
                                                        <button type="submit" name="submit" class="btn btn-info btn-lg btn-block mt-3">Submit</button>
                                                    </div>
                                                    <!-- /.col-sm-12 -->
                                                </div>
                                                <!-- /.form-group -->
                                            </div>
                                            <!-- /.form-actions -->
                                        </div>
                                        <!-- /.col-md-12 -->
                                    </div>
                                    <!-- /.row -->
                                </form>
                              