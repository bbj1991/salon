<div class="main-container">
<h3>user</h3>

    <form method="post" enctype="multipart/form-data"> 
     
                                  <div class="row">
                                  <div class="col-md-4">
                                  <div class="form-group">
                                      <label class="form-control-label">branch:</label>
                                         <select class="form-control" required name="data[branch]">
                                         <?php $br=$this->db->get_where('branch',array('status'=>1))->result(); foreach ($br as $v) {?>
                                         <option value="<?php echo $v->id; ?>"><?php echo $v->name; ?></option>
                                        <?php } ?>
                                         
                                      </select>
                                    
                                  </div>
                                  
                                  <!-- /.form-group -->
                              </div>
                              <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">name:</label>
                                                 <input type="text" id="sample5FirstName" class="form-control"  name="data[name]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">email:</label>
                                                 <input type="email" id="sample5FirstName" class="form-control"  name="data[email]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">password:</label>
                                                 <input type="text" id="sample5FirstName" class="form-control"  name="data[password]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
                              
                                                
                                                
  <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">phone:</label>
                                                 <input type="number" id="sample5FirstName" class="form-control"  name="data[phone]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">Photo </label>
                                                <input type="file" id="sample5FirstName" class="form-control"  name="photo" >                                               
                                            </div>                                          
                                            </div>
                                   
                                        <div class="col-md-6">
    <h4>Address</h4>
    <div class="form-group">
      <textarea rows="3" name="data[address]" required class="form-control"></textarea>
    </div>
  </div>
                                          <div class="col-md-6">
    <h4>Details</h4>
    <div class="form-group">
      <textarea rows="3" name="data[details]" class="form-control"></textarea>
    </div>
  </div>
                                    </div>
 
  <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-actions">
                                                <div class="form-group">
                                                    <div class="btn-list">
                                                        <button type="submit" name="add_user" class="btn btn-primary">Submit</button>
                                                       <!--  <button type="button" class="btn btn-default">Cancel</button> -->
                                                    </div>
                                                    <!-- /.col-sm-12 -->
                                                </div>
                                                <!-- /.form-group -->
                                            </div>
                                            <!-- /.form-actions -->
                                        </div>
                                        <!-- /.col-md-12 -->
                                    </div>
</form>
</div>