
<div class="main-container">
<h3>Add New Service</h3>
<form method="post" enctype="multipart/form-data">
<div class="row">
                                    <div class="col-4">
                                  <div class="form-group">
                                      <h4>Category:</h4>
                                         <select class="form-control" required name="data[category]">
                                         <?php $br=$this->db->get_where('category',array('status'=>1))->result(); foreach ($br as $v) {?>
                                         <option value="<?php echo $v->id; ?>"><?php echo $v->name; ?></option>
                                        <?php } ?>
                                         
                                      </select>
                                    
                                  </div>
                              </div>
      <div class="col-4">
        <h4>Name</h4>
        <div class="form-group">
          <input type="text" placeholder="" class="form-control" name="data[name]" required>
        </div>
      </div>

       <div class="col-4">
        <h4>Price in Rupees</h4>
        <div class="form-group">
          <input type="text" placeholder="" class="form-control" name="data[price]" required>
        </div>
      </div>
       <div class="col-4">
        <h4>Time in min</h4>
        <div class="form-group">
          <input type="text" placeholder="" class="form-control" name="data[time]" required>
        </div>
      </div>

      <div class="col-6">
        <h4>Details</h4>
        <div class="form-group">
          <textarea rows="3" placeholder="" class="form-control" name="data[details]"></textarea>
        </div>
      </div>
    </div>
 <div class="row">
     <div class="col-12">
          <div class="form-actions">
             <div class="form-group">
               <div class="btn-list">
                    <button type="submit" name="add_service" class="btn btn-primary">Submit</button>
                                                      
                         </div>
                                                    
                                </div>
                                               
                       </div>
                                          
               </div>
                                       
        </div>
      </form>

</div>

