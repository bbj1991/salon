<?php $bid=$this->session->userdata('login')->branch; ?>
    
<h3>New Appointment</h3>
<hr>
    <div class="row" id="fc"></div>

   <hr>

<div class="main-container">
<form method="post" enctype="multipart/form-data">

    <div class="row">

          <input type="hidden" name="data[customer]" value="<?php echo $id ?>" required>
<div class="col-md-4">
                                  <div class="form-group">
                                      <label class="form-control-label">Customer Services:</label>
                                         <select class="form-control  " required name="data[service]">
                                           <?php $br=$this->db->get_where('cas',array('customer'=>$id))->result(); foreach ($br as $v) {?>
                                         <option value="<?php echo $v->id; ?>"><?php echo $v->sname; ?></option>
                                        <?php } ?>
                                         
                                      </select>
                                    
                                  </div>
                                  
                                  <!-- /.form-group -->
                              </div>
  <div class="col-md-4">
                                  <div class="form-group">
                                      <label class="form-control-label">Staff :</label>
                                         <select class="form-control " required name="data[staff]">
                                           <?php $br=$this->db->get_where('staff',array('branch'=>$bid,'status'=>1))->result(); foreach ($br as $v) {?>
                                         <option value="<?php echo $v->id; ?>"><?php echo $v->name; ?></option>
                                        <?php } ?>
                                         
                                      </select>
                                    
                                  </div>
                                  
                                  <!-- /.form-group -->
                              </div>
                                <div class="col-md-4">
                                  <div class="form-group">
                                      <label class="form-control-label">Date Time :</label>
                                         <input type="text" class="form-control " required name="data[datetime]">
                                  </div>
                                  
                                  <!-- /.form-group -->
                              </div>
    </div>



 <div class="row">
      <div class="col-12">
        <h4>Details</h4>
        <div class="form-group">
          <textarea rows="3" placeholder="" class="form-control" name="data[details]"></textarea>
        </div>
      </div>
      </div>

 <div class="row">
     <div class="col-12">
          <div class="form-actions">
             <div class="form-group">
               <div class="btn-list">
                    <button type="submit" name="add_appointment" class="btn btn-primary">Submit</button>
                                                      
                         </div>
                                                    
                                </div>
                                               
                       </div>
                                          
               </div>
                                       
        </div>
      </form>

</div>
 <script type="text/javascript">

    function chkcust(id) {
       if(id){
        $.post("<?php echo base_url('customer/getview'); ?>/"+id, function(data, status){
       $('#fc').html(data);
       });
    }
    
  }
  chkcust(<?php echo $id; ?>);
  </script>  