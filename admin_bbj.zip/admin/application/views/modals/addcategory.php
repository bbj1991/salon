
<div class="main-container">
<h3>Add Category</h3>
<form method="post" enctype="multipart/form-data">
<div class="row">
      <div class="col-6">
        <h4>Name</h4>
        <div class="form-group">
          <input type="text" placeholder="" class="form-control" name="data[name]" required>
        </div>
      </div>
      <div class="col-6">
      <h4> .</h4>
             <div class="form-group">
               <div class="btn-list">
                    <button type="submit" name="add_category" class="btn btn-primary">Submit</button>
                                                      
                         </div>

                                          
               </div>
                                          
               </div>
                                       
        </div>
      </form>

</div>

