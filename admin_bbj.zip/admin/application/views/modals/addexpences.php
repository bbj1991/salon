

<div class="page-wrap">
<div class="page-content">

<div class="container-fluid">
<div class="page-content__header">
<div>
  <h2 class="page-content__header-heading">Expences</h2>
</div>
</div>
<div class="main-container">
<h3>Add expences</h3>
<form method="post" enctype="multipart/form-data">
<div class="row">
      <div class="col-3">
        <h4>Branch</h4>
        <div class="form-group">
        <select class="form-control" name="data[branch]">
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="opel">Opel</option>
  <option value="audi">Audi</option>
</select>
        </div>
      </div>
       <div class="col-3">
        <h4>Staff</h4>
        <div class="form-group">
        <select class="form-control" name="data[staff]">
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="opel">Opel</option>
  <option value="audi">Audi</option>
</select>
        </div>
      </div>
          <div class="col-3">
        <h4>Type</h4>
        <div class="form-group">
        <select class="form-control" name="data[type]">
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="opel">Opel</option>
  <option value="audi">Audi</option>
</select>
        </div>
      </div>
        <div class="col-3">
        <h4>Amount</h4>
        <div class="form-group">
          <input type="text" placeholder="" class="form-control" name="data[amount]">
        </div>
      </div>
      <div class="col-6">
        <h4>Details</h4>
        <div class="form-group">
          <textarea rows="3" placeholder="" class="form-control" name="data[details]"></textarea>
        </div>
      </div>
    </div>
 <div class="row">
     <div class="col-12">
          <div class="form-actions">
             <div class="form-group">
               <div class="btn-list">
                    <button type="submit" name="add_expences" class="btn btn-primary">Submit</button>
                                                      
                         </div>
                                                    
                                </div>
                                               
                       </div>
                                          
               </div>
                                       
        </div>
      </form>
</div>

</div>

</div>
</div>

