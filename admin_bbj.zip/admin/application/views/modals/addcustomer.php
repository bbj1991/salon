<div class="main-container">
<h3>Customer</h3>
 <form method="post"  enctype="multipart/form-data"> 
     
<div class="row"> 
 <div class="col-md-4">
  <div class="form-group">
<label  class="form-control-label">name:</label>
<input type="text"  class="form-control"  name="data[name]" required >
 </div>
</div>
<div class="col-md-4">
  <div class="form-group">
    <label  class="form-control-label">gender:</label>
                         <select class="form-control" required name="data[gender]">
                                      <option value="male">Male</option>
                                      <option value="female">Female</option>
                                  </select>                                                
                                            </div>                                          
                                            </div>

                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">email:</label>
                                                 <input type="email"  class="form-control"  name="data[email]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">phone:</label>
                                                 <input type="number"  class="form-control"  name="data[phone]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>

                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">phone 2:</label>
                                                 <input type="number"  class="form-control"  name="data[altphone]"   required="required">                                                
                                            </div>                                          
                                            </div>
                                                                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">Birthday:</label>
                                                 <input type="number"  class="form-control"  name="data[dob]"   required="required">                                                
                                            </div>                                          
                                            </div>
    <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">Photo </label>
                                                <input type="file"  class="form-control"  name="photo" >                                               
                                            </div>
                                            <!-- /.form-group -->
                                        </div>

  <div class="col-md-6">
    <h4>Address</h4>
    <div class="form-group">
      <textarea rows="3" name="data[address]" required class="form-control"></textarea>
    </div>
  </div>
    <div class="col-md-6">
    <h4>details</h4>
    <div class="form-group">
      <textarea rows="3" name="data[details]" class="form-control"></textarea>
    </div>
  </div>

 
                                        
                                    </div>
                                            
 
                                            
  

  
  <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-actions">
                                                <div class="form-group">
                                                    <div class="btn-list">
                                                        <button type="submit" name="add_customer" class="btn btn-primary">Submit</button>
                                                       <!--  <button type="button" class="btn btn-default">Cancel</button> -->
                                                    </div>
                                                    <!-- /.col-sm-12 -->
                                                </div>
                                                <!-- /.form-group -->
                                            </div>
                                            <!-- /.form-actions -->
                                        </div>
                                        <!-- /.col-md-12 -->
                                    </div>

</form>
</div>