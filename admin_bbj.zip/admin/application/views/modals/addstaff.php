<div class="main-container">
<h3>staff</h3>

    <form method="post"  enctype="multipart/form-data"> 
     
                                  <div class="row">
                                  <div class="col-md-4">
                                  <div class="form-group">
                                      <label class="form-control-label">branch:</label>
                                         <select class="form-control " required name="data[branch]">
                                         <?php $br=$this->db->get_where('branch',array('status'=>1))->result(); foreach ($br as $v) {?>
                                         <option value="<?php echo $v->id; ?>"><?php echo $v->name; ?></option>
                                        <?php } ?>
                                         
                                      </select>
                                    
                                  </div>
                                  
                                  <!-- /.form-group -->
                              </div>
                              <div class="col-md-4">
                              <div class="form-group">
                                  <label class="form-control-label">Role:</label>
                                     <select class="form-control" required name="data[role]">
                                      <option value="role1">Role 1</option>
                                      <option value="role2">Role 2</option>
                                      <option value="role3">Role 3</option>
                                      <option value="role4">Role 4</option>
                                      <option value="role5">Role 5</option>
                                  </select>
                                
                              </div>
                              
                              <!-- /.form-group -->
                          </div>
                             
                              <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">gender:</label>
                         <select class="form-control" required name="data[gender]">
                                      <option value="male">Male</option>
                                      <option value="female">Female</option>
                                  </select>                                                
                                            </div>                                          
                                            </div>
                                            <div class="col-md-4">
                                            <div class="form-group">
<label  class="form-control-label">name:</label>
<input type="text"  class="form-control"  name="data[name]" required >                                                
                                            </div>                                          
                                            </div>
                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">email:</label>
                                                 <input type="email"  class="form-control"  name="data[email]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">phone:</label>
                                                 <input type="number"  class="form-control"  name="data[phone]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
                              
                                                
                                                
  <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">Emergency contact:</label>
 <input type="text"  class="form-control"  name="data[contact]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">phone:</label>
                                                 <input type="number"  class="form-control"  name="data[altphone]"   required="required">                                                
                                            </div>                                          
                                            </div>


                                            <div class="col-md-4">
                                            <div class="form-group">
                                                <label  class="form-control-label">salary:</label>
                                                 <input type="number"  class="form-control"  name="data[salary]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
  <div class="col-md-6">
    <h4>Address</h4>
    <div class="form-group">
      <textarea rows="3" name="data[address]" required class="form-control"></textarea>
    </div>
  </div>
    <div class="col-md-6">
    <h4>details</h4>
    <div class="form-group">
      <textarea rows="3" name="data[details]" class="form-control"></textarea>
    </div>
  </div>
                                            <div class="col-md-3">
                                            <div class="form-group">
                                                <label  class="form-control-label">Photo </label>
                                                <input type="file"  class="form-control"  name="photo" >                                               
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label  class="form-control-label">idproof </label>
                                                <input type="file"  class="form-control"  name="idproof" >                                               
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label  class="form-control-label">addrproof</label>
                                                <input type="file"  class="form-control"  name="addrproof" >                                            
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label  class="form-control-label">other</label>
                                                <input type="file"  class="form-control"  name="other" >                                               
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                        
                                    </div>
                                            
 
                                            
  

  
  <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-actions">
                                                <div class="form-group">
                                                    <div class="btn-list">
                                                        <button type="submit" name="add_staff" class="btn btn-primary">Submit</button>
                                                       <!--  <button type="button" class="btn btn-default">Cancel</button> -->
                                                    </div>
                                                    <!-- /.col-sm-12 -->
                                                </div>
                                                <!-- /.form-group -->
                                            </div>
                                            <!-- /.form-actions -->
                                        </div>
                                        <!-- /.col-md-12 -->
                                    </div>


</div>