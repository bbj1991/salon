

<div class="page-wrap">
<div class="page-content">

<div class="container-fluid">
<div class="page-content__header">
<div>
  <h2 class="page-content__header-heading">attendance</h2>
</div>
</div>
<div class="main-container">
<h3>Attendence Elements</h3>

    <form method="post"> 
     
                                  <div class="row">
                                  <div class="col-md-3">
                                  <div class="form-group">
                                      <label class="form-control-label">Branch:</label>
                                         <select class="form-control" req="" name="[Branch]">
                                          <option value="All employees">All employees</option>
                                          <option value="All customers">All customers</option>
                                         
                                      </select>
                                    
                                  </div>
                                  
                                  <!-- /.form-group -->
                              </div>
                              <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="form-control-label">Staff:</label>
                                                       <select class="form-control" req="" name="[Staff]">
                                                        <option value="All employees">All employees</option>
                                                        <option value="All customers">All customers</option>
                                                       
                                                    </select>
                                                  
                                                </div>
                                                
                                                <!-- /.form-group -->
                                            </div>
                                            
                                            <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">Date:</label>
                                                 <input type="date" id="sample5FirstName" class="form-control"  name="[Date]" 
                                                required="required">                                                
                                            </div>                                          
                                            </div>
                                            
                                            <div class"row">
                                            <div class="col-md-">
                                                <div class="form-group">
                                                    <label class="form-control-label">Type:</label>
                                                       <select class="form-control" req="" name="[Type]">
                                                        <option value="prasent">prasent</option>
                                                        <option value="absent">absent</option>
                                                        <option value="holiday">holiday</option>
                                                        <option value="leave">leave</option>
                                                        
                                                       
                                                    </select>
                                                  
                                                </div>
                                                </div></div>
 
  </div>
  <div class="col-md-6">
    <h4>details</h4>
    <div class="form-group">
      <textarea rows="3" placeholder="Favorite NBA Team" class="form-control"></textarea>
    </div>
  </div>
  <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-actions">
                                                <div class="form-group">
                                                    <div class="btn-list">
                                                        <button type="submit" name="add_attendance" class="btn btn-primary">Submit</button>
                                                       <!--  <button type="button" class="btn btn-default">Cancel</button> -->
                                                    </div>
                                                    <!-- /.col-sm-12 -->
                                                </div>
                                                <!-- /.form-group -->
                                            </div>
                                            <!-- /.form-actions -->
                                        </div>
                                        <!-- /.col-md-12 -->
                                    </div>


