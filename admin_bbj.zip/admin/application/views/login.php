<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/favicon.png">
  <title>Welcome / MLM Admin</title>

  
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/open-sans/style.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/iconfont/iconfont.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/flatpickr/flatpickr.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/tippyjs/tippy.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/select2/css/select2.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.min.css" id="stylesheet">
  

  <script src="<?php echo base_url(); ?>assets/js/ie.assign.fix.min.js"></script>
</head>
<body class="p-front p-signup-helper">

<div class="preloader">
  <div class="loader">
    <span class="loader__indicator"></span>
    <div class="loader__label"><img src="<?php echo base_url(); ?>assets/img/logo.png" alt=""></div>
  </div>
</div>
<div class="p-front__content">
  <div class="p-signin-a">

  <form method="post" class="p-signin-a__form">
  
    <h4 class="p-signin-a__form-heading">Sign In</h4>

 <p class="p-signin-a__form-description">Welcome to GOLD BEAUTY MANAGEMENT</p>
    <div class="form-group">
      <input type="email" class="form-control form-control-lg" name="username" placeholder="Email">
    </div>
    <div class="form-group">
      <input type="password" class="form-control form-control-lg" name="password" placeholder="Password">
    </div>
    <div class="form-group">
      <button class="btn btn-info btn-lg btn-block btn-rounded" name="submit" type="submit">Sign In</button>
    </div>

  </form>
</div>
</div>

  <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/popper/popper.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/simplebar/simplebar.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/text-avatar/jquery.textavatar.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/tippyjs/tippy.all.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/flatpickr/flatpickr.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/wnumb/wNumb.js"></script>
<script src="<?php echo base_url(); ?>assets/js/main.js"></script>

<script src="<?php echo base_url(); ?>/assets/js/notify.js"></script>
    <script type="text/javascript">
    <?php if(@$this->session->userdata('SMSG')){ ?>
        $.notify("<?php echo $this->session->userdata('SMSG'); ?>",'success');

   <?php $this->session->set_userdata('SMSG',''); }?>
    <?php if(@$this->session->userdata('EMSG')){ ?>
        $.notify("<?php echo $this->session->userdata('EMSG'); ?>");

   <?php $this->session->set_userdata('EMSG',''); }?>
    </script>
</body>

</html>
