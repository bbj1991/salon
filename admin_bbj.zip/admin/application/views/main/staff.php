  
<div class="container-fluid">
  <div class="main-container">
<button class="btn-sm btn-info mt-3 " onclick="mymodal('addstaff');">
            New Staff
    </button> 
   <hr>
<h3>Staff List</h3>
    <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('staff',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                         <td><?php echo $v->name; ?></td>
                                          <td><?php echo $v->email; ?></td>
                                           <td><?php echo $v->phone; ?></td>
                                        <td><?php  if ($v->status) { ?>
                                          <a class="btn btn-xs  btn-success"  onclick="inactive('staff',<?php echo $v->id; ?>);">Active
                                                </a>
                                      <?php   }else{?>
                                      <a class="btn btn-xs  btn-success"  onclick="inactive('staff',<?php echo $v->id; ?>);">Active
                                                </a>
                                      <?php } ?>
                                              </td>
                                                <td> <a class="btn btn-xs  btn-warning" onclick="mymodal('viewstaff',<?php echo $v->id; ?>);" >View
                                                </a> 
                                                <a class="btn btn-xs  btn-primary"  onclick="mymodal('editstaff',<?php echo $v->id; ?>);"  >Edit
                                                </a></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
</div>
</div></div>
</div>

  