   
<div class="container-fluid">
  <div class="main-container">
    <button type="button" class="btn-sm btn-info mt-3" onclick="mymodal('adduser');">
            New User
    </button>
   <hr>
  <div class="container-fluid">
   <h3>Users list</h3>
  <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Location</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('user',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                        <td><?php echo $this->fun->getfv('branch','name',$v->branch); ?></td>
                                         <td><?php echo $v->name; ?></td>
                                          <td><?php echo $v->email; ?></td>
                                           <td><?php echo $v->phone; ?></td>
                                        <td><?php  if ($v->status) { ?>
                                          <a class="btn-sm btn-success"  onclick="status(this,'user',<?php echo $v->id; ?>);">Active
                                                </a>
                                      <?php   }else{?>
                                      <a class="btn-sm btn-warning"  onclick="status(this,'user',<?php echo $v->id; ?>,1);">InActive
                                                </a>
                                      <?php } ?>
                                              </td>
                                                <td> <a class="btn btn-xs  btn-warning" onclick="mymodal('viewuser',<?php echo $v->id; ?>);" >View
                                                </a> 
                                                <a class="btn btn-xs  btn-primary"  onclick="mymodal('edituser',<?php echo $v->id; ?>);"  >Edit
                                                </a></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
</div>
</div></div>
</div>

  