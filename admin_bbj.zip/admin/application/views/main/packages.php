   
<div class="container-fluid">
  <div class="main-container">
    <button type="button" class="btn-sm btn-info mt-3" onclick="mymodal('addpackage');">
            New Packages
    </button>   <hr>
  <div class="container-fluid">
   <h3>Packages list</h3>
  <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>price</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('package',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                         <td><?php echo $v->name; ?></td>
                                           <td><?php echo $v->price; ?></td>
                                        <td><?php  if ($v->status) { ?>
                                          <a class="btn-sm btn-success"  onclick="status(this,'package',<?php echo $v->id; ?>);">Active
                                                </a>
                                      <?php   }else{?>
                                      <a class="btn-sm btn-warning"  onclick="status(this,'package',<?php echo $v->id; ?>,1);">InActive
                                                </a>
                                      <?php } ?>
                                              </td>
                                                <td> <a class="btn btn-xs  btn-warning" onclick="mymodal('viewpackage',<?php echo $v->id; ?>);" >View
                                                </a> 
                                                <a class="btn btn-xs  btn-primary"  onclick="mymodal('editpackage',<?php echo $v->id; ?>);"  >Edit
                                                </a></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
</div>
</div></div>
</div>

  