  
<div class="container-fluid">
  <div class="main-container">
    <button class="btn-sm btn-info mt-3 " onclick="mymodal('addcategory');">
            New category
    </button> <button class="btn-sm btn-info mt-3 " onclick="mymodal('addservice');">
            New service
    </button> 
   <hr>

  <div class="container-fluid">
    <div class="row">
      
    <div class=" col-md-3 m-datatable">
      <h3>categories</h3>
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>category</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;   $br=$this->db->get_where('category',array())->result();
                                        foreach ($br as $v) {  ?>
                                    <tr>
                                         <td><?php echo $v->name; ?></td>
                                        <td><?php  if ($v->status) { ?>
                                          <a class="btn-sm btn-success"  onclick="status(this,'category',<?php echo $v->id; ?>);">Active
                                                </a>
                                      <?php   }else{?>
                                      <a class="btn-sm btn-warning"  onclick="status(this,'category',<?php echo $v->id; ?>,1);">InActive
                                                </a>
                                      <?php } ?>
                                              </td>
                                                <td>
                                                <a class="btn btn-xs  btn-primary"  onclick="mymodal('editcategory',<?php echo $v->id; ?>);"  >Edit
                                                </a></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div><div class="  col-md-9 m-datatable">

      <h3>services</h3>
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>category</th>
                                        <th>price</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('service',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                         <td><?php echo $v->name; ?></td>
                                          <td><?php echo $this->fun->getfv('category','name',$v->category); ?></td>
                                           <td><?php echo $v->price; ?></td>
                                        <td><?php  if ($v->status) { ?>
                                          <a class="btn-sm btn-success"  onclick="status(this,'service',<?php echo $v->id; ?>);">Active
                                                </a>
                                      <?php   }else{?>
                                      <a class="btn-sm btn-warning"  onclick="status(this,'service',<?php echo $v->id; ?>,1);">InActive
                                                </a>
                                      <?php } ?>
                                              </td>
                                                <td> <a class="btn btn-xs  btn-warning" onclick="mymodal('viewservice',<?php echo $v->id; ?>);" >View
                                                </a> 
                                                <a class="btn btn-xs  btn-primary"  onclick="mymodal('editservice',<?php echo $v->id; ?>);"  >Edit
                                                </a></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>

    </div>
  </div>
</div></div>
</div>

  