<div class="container-fluid">
  <div class="main-container">
    <h3>Users</h3>
    <hr>
<form method="post">
                                 <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">Location Name</label>
                                                <select class="form-control"   required name="data[location]" >
                                                <option>select</option>
                                                <?php $lo=$this->db->get_where('locations',array('status'=>'1'))->result();
                                                foreach ($lo as $l) {?>
                                                  <option value="<?php echo $l->id; ?>"><?php echo $l->location; ?></option>
                                                <?php } ?>
                                                </select>                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                         <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label"> Name</label>
                                                <input type="text" id="sample5FirstName" class="form-control"   required name="data[name]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">Email</label>
                                                <input type="text" id="sample5FirstName" class="form-control"   required name="data[email]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                         <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label"> Password</label>
                                                <input type="password" id="sample5FirstName" class="form-control"   required name="data[password]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    
                                
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label">Phone</label>
                                                <input type="text" id="sample5FirstName" class="form-control"   required name="data[phone]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                         <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="sample5FirstName" class="form-control-label"> address</label>
                                                <input type="text" id="sample5FirstName" class="form-control"   required name="data[address]">                                                
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-actions">
                                                <div class="form-group">
                                                    <div class="btn-list">
                                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                                    </div>
                                                    <!-- /.col-sm-12 -->
                                                </div>
                                                <!-- /.form-group -->
                                            </div>
                                            <!-- /.form-actions -->
                                        </div>
                                        <!-- /.col-md-12 -->
                                    </div>
                                    <!-- /.row -->
                                </form>
  </div>
  <div class="main-container">
  <div class="container-fluid">
   <h3>Users list</h3>
   <hr>
  <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Location</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('admin',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                        <td><?php echo $this->fun->getfv('locations','location',$v->location); ?></td>
                                         <td><?php echo $v->name; ?></td>
                                          <td><?php echo $v->email; ?></td>
                                           <td><?php echo $v->phone; ?></td>
                                        <td> <a class="btn btn-xs  btn-success">Active
                                                </a>
                                              </td>
                                                <td> <a class="btn btn-xs  btn-warning" href="<?php echo base_url("users/view/".$v->id); ?>">View
                                                </a> 
                                                <a class="btn btn-xs  btn-primary" href="<?php echo base_url("users/edit/".$v->id); ?>">Edit
                                                </a></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
</div>
</div></div>
</div>

  