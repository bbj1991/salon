
    
<div class="container-fluid container-fh">
  <div class="page-content__header">
    <div>
      <h2 class="page-content__header-heading">Blank page</h2>
    </div>
  </div>
  <div class="main-container container-fh__content">
    content
  </div>
</div>

  