<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <title>Dashboard /MLM Admin</title>
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets/img/favicon.png">

  
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/fonts/open-sans/style.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/fonts/iconfont/iconfont.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/vendor/flatpickr/flatpickr.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/vendor/tippyjs/tippy.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/vendor/select2/css/select2.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.min.css" id="stylesheet">

  

  <script src="<?php echo base_url(); ?>/assets/js/ie.assign.fix.min.js"></script>
</head>
<body class="js-loading sidebar-hidden navbar-ecommerce-static">
