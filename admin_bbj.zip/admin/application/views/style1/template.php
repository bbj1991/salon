<?php $this->load->view('style1/head'); ?>
<div class="page-wrap">
	<div class="page-content">
<?php $this->load->view($page,$data); ?>
  </div>
</div>
<?php $this->load->view('style1/foot'); ?>