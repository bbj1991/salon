  <div class="navbar navbar-ecommerce"> <!-- is-dark -->
  <div class="navbar-ecommerce__top-side">
    <div>
      <a class="navbar-brand" href="<?php echo base_url(); ?>">
        <!-- <img src="<?php echo base_url(); ?>/assets/img/logo.png" alt=""/> -->
          <span style="color: #94e6c9;">ADMIN</span>
        </a>
      <a class="navbar-brand-sm" href="<?php echo base_url(); ?>">
        <!-- <img src="<?php echo base_url(); ?>/assets/img/logo-sm.png" alt=""/> -->
        <span style="color: #94e6c9;">ADMIN</span></a>
    </div>

    <div class="navbar-collapse" id="navbar-collapse" >
      <div class="navbar-ecommerce__navbar-collapse"  >
        <span class="navbar-search" style="margin-left: 50% !important; ">
<!--           <div class="input-group iconfont icon-right">
            <input class="form-control navbar-search__input" type="text" id="navsearch" placeholder="Search">
            <span class="input-icon iconfont iconfont-search"></span>
          </div> -->
        </span>
        <span class="dropdown navbar-dropdown" >
          <a class="dropdown-toggle navbar-dropdown-toggle navbar-dropdown-toggle__user" data-toggle="dropdown" href="#">
            <img src="<?php echo base_url(); ?>/assets/img/users/user-3.png" alt="" class="navbar-dropdown-toggle__user-avatar">
            <span class="navbar-dropdown__user-name"><?php $Ul= $this->session->userdata('login'); echo $Ul->name,"( $Ul->type )"; ?></span>
          </a>
          <div class="dropdown-menu navbar-dropdown-menu navbar-dropdown-menu__user">
            <div class="navbar-dropdown-user-content">
              <div class="dropdown-user__avatar">
                <img src="<?php echo base_url(); ?>/assets/img/users/user-3.png" alt=""/></div>
              <div class="dropdown-info">
                <div class="dropdown-info__name"><?php echo $Ul->name; ?></div>
                <div class="dropdown-info__job"><?php echo $Ul->email; ?></div>
                <div class="dropdown-info__job"><?php //echo $Ul->location; ?></div>
                  <div class="dropdown-divider"></div>
                   <div class="dropdown-info-buttons">
                  <a class="dropdown-info__addaccount" href="#">Change Password</a>
                  <a class="dropdown-info__viewprofile" href="<?php echo base_url('logout'); ?>">Logout</a></div>
              </div>
            </div>
          </span>
        </div>
      </div>
    </div>
  </div>
  <div class="navbar-ecommerce__tabs">
    <nav class="nav nav-tabs">
      <?php if ($Ul->type=='ADMIN') {?>
      <a class="nav-item nav-link "  href="<?php echo base_url('dashboard'); ?>">Dashboard</a>
            <a class="nav-item nav-link" href="<?php echo base_url('management/branches'); ?>">Branches</a>
            <a class="nav-item nav-link" href="<?php echo base_url('management/users'); ?>">Users</a>
            <a class="nav-item nav-link" href="<?php echo base_url('management/staff'); ?>">Staff</a>
            <a class="nav-item nav-link" href="<?php echo base_url('management/services'); ?>">Services</a>
            <a class="nav-item nav-link" href="<?php echo base_url('management/products'); ?>">Products</a>
            <a class="nav-item nav-link" href="<?php echo base_url('management/packages'); ?>">Packages</a>
            <?php } ?>
    </nav>
  </div>
</div>