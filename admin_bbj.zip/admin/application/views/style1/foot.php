<script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/vendor/popper/popper.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/vendor/simplebar/simplebar.js"></script>
<script src="<?php echo base_url(); ?>/assets/vendor/text-avatar/jquery.textavatar.js"></script>
<script src="<?php echo base_url(); ?>/assets/vendor/tippyjs/tippy.all.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/vendor/flatpickr/flatpickr.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/vendor/wnumb/wNumb.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/main.js"></script>
 
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
<!-- Data Tabels --><!-- 
<script src="<?php echo base_url(); ?>/assets/vendor/datatables/datatables.min.js"></script> -->

<!-- Grolw Notifications -->
<script src="<?php echo base_url(); ?>/assets/vendor/prism/prism.js"></script>
 
<script src="<?php echo base_url(); ?>/assets/js/growl-notification/growl-notification.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/preview/growl-notifications.min.js"></script>

<script src="<?php echo base_url(); ?>/assets/js/notify.js"></script>

<script type="text/javascript">
	function mymodal(page,id='') {
		$.post("<?php echo base_url('management/modal'); ?>",{"id":id,"page":page}, function(data, status){
			$('#bbjcontent').html(data);
			$('#bbjmodal').modal('show');
    });
	}
</script>
<script type="text/javascript">
	function status(e,t,id,s=0) {
		$.post("<?php echo base_url('management/status'); ?>",{"id":id,"t":t,"status":s}, function(data, status){
			if (data=='2') {

			$(e).attr('onclick',"status(this,'"+t+"','"+id+"','1');");
			$(e).attr('class',"btn-sm btn-warning");
			$(e).html('InActive');

			}else if (data=='1') {

	$(e).attr('onclick',"status(this,'"+t+"','"+id+"');");
	$(e).attr('class',"btn-sm btn-success");
	$(e).html('Active');
			}
    });
	}
</script>

<?php //$this->load->view('style1/overlay'); ?>

<script src="<?php echo base_url(); ?>/assets/js/preview/settings-panel.min.js"></script>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script><!-- 
<script src="<?php echo base_url(); ?>/assets/js/preview/datatables1.min.js"></script> -->
    <script type="text/javascript">
    <?php if(@$this->session->userdata('SMSG')){ ?>
        $.notify("<?php echo $this->session->userdata('SMSG'); ?>",'success');

   <?php $this->session->set_userdata('SMSG',''); }?>
    <?php if(@$this->session->userdata('EMSG')){ ?>
        $.notify("<?php echo $this->session->userdata('EMSG'); ?>");

   <?php $this->session->set_userdata('EMSG',''); }?>
    </script>
    <script type="text/javascript">
     $('.DT').DataTable();
     $('#navsearch').select2({
  ajax: {
    url: 'https://api.github.com/search/repositories',
    dataType: 'json'
    // Additional AJAX parameters go here; see the end of this chapter for the full code of this example
  }
});
    </script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/list.js/1.5.0/list.min.js"></script>
<script type="text/javascript">
  var List = new List('clist', {
  valueNames: ['name','email'],
  page: 12,
  pagination: true
});
</script>
</body>
</html>
