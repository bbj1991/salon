  <div class="navbar navbar-ecommerce"> <!-- is-dark -->
  <div class="navbar-ecommerce__top-side">
    <div>
      <a class="navbar-brand" href="<?php echo base_url(); ?>">
        <!-- <img src="<?php echo base_url(); ?>/assets/img/logo.png" alt=""/> -->
          <span style="color: #94e6c9;">ADMIN</span>
        </a>
      <a class="navbar-brand-sm" href="<?php echo base_url(); ?>">
        <!-- <img src="<?php echo base_url(); ?>/assets/img/logo-sm.png" alt=""/> -->
        <span style="color: #94e6c9;">ADMIN</span></a>
    </div>

    <div class="navbar-collapse" id="navbar-collapse" >
      <div class="navbar-ecommerce__navbar-collapse"  >
        <span class="navbar-search" style="margin-left: 50% !important; ">
          <div class="input-group iconfont icon-right">
            <input class="form-control navbar-search__input" type="text" id="navsearch" placeholder="Search">
            <span class="input-icon iconfont iconfont-search"></span>
          </div>
        </span>
        <span class="dropdown navbar-dropdown" >
          <a class="dropdown-toggle navbar-dropdown-toggle navbar-dropdown-toggle__user" data-toggle="dropdown" href="#">
            <img src="<?php echo base_url(); ?>/assets/img/users/user-3.png" alt="" class="navbar-dropdown-toggle__user-avatar">
            <span class="navbar-dropdown__user-name"><?php $Ul= $this->session->userdata('login'); echo $Ul->name,"( $Ul->type )"; ?></span>
          </a>
          <div class="dropdown-menu navbar-dropdown-menu navbar-dropdown-menu__user">
            <div class="navbar-dropdown-user-content">
              <div class="dropdown-user__avatar"><img src="<?php echo base_url(); ?>/assets/img/users/user-3.png" alt=""/></div>
              <div class="dropdown-info">
                <div class="dropdown-info__name"><?php echo $Ul->name; ?></div>
                <div class="dropdown-info__job"><?php echo $Ul->email; ?></div>
                <div class="dropdown-info__job"><?php //echo $Ul->location; ?></div>
                  <div class="dropdown-divider"></div>
                   <div class="dropdown-info-buttons">
                  <a class="dropdown-info__addaccount" href="#">Change Password</a>
                  <a class="dropdown-info__viewprofile" href="<?php echo base_url('logout'); ?>">Logout</a></div>
              </div>
            </div>
          </span>
        </div>
      </div>
    </div>
  </div>
  <div class="navbar-ecommerce__tabs">
    <nav class="nav nav-tabs">
      <a class="nav-item nav-link " data-toggle="tab" href="#nav-dash">Dashboard</a>
      <?php if ($Ul->type=='ADMIN') {?>
      <a class="nav-item nav-link <?php if($this->uri->segment(1,0)=='management') echo 'active'; ?>" data-toggle="tab" href="#nav-mang">Management</a>
      <?php } ?>
      <a class="nav-item nav-link <?php if($this->uri->segment(1,0)=='customer'||$this->uri->segment(1,0)=='dashboard'||$this->uri->segment(1,0)=='') echo 'active'; ?>" data-toggle="tab" href="#nav-cust">Customers</a>
      <a class="nav-item nav-link" data-toggle="tab" href="#nav-expe">Expences</a>      
      <a class="nav-item nav-link" data-toggle="tab" href="#nav-staf">Staff</a>
<!--       <a class="nav-item nav-link" data-toggle="tab" href="#nav-inve">Inventory</a>      
 -->      <a class="nav-item nav-link" data-toggle="tab" href="#nav-repo">Reports</a>        
        
        
    </nav>
    <div class="tab-content">
      <div class="tab-pane fade " id="nav-dash"></div>
      <div class="tab-pane fade  <?php if($this->uri->segment(1,0)=='customer'||$this->uri->segment(1,0)=='dashboard'||$this->uri->segment(1,0)=='') echo 'show active'; ?> " id="nav-cust">
        <ul class="nav navbar-ecommerce__menu">

          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('customer'); ?>">Customer</a>
          </li>
                    <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('customer/enquiries'); ?>">Enquiries</a>
          </li>
                    <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('customer/appointments'); ?>">Appointments</a>
          </li>
                    <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('customer/bills'); ?>">Bills</a>
          </li>
                <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('customer/payments'); ?>">Payments</a>
          </li>
<!--  <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('customer/todoservices'); ?>">Assign Service</a>
          </li> -->

        </ul>
      </div>
      <div class="tab-pane fade" id="nav-staf">
                <ul class="nav navbar-ecommerce__menu">

          <li class="nav-item">
            <a class="nav-link" href="#">Attendence</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Salary</a>
          </li>
        </ul>
      </div>
            <div class="tab-pane fade" id="nav-inve">
                <ul class="nav navbar-ecommerce__menu">

          <li class="nav-item">
            <a class="nav-link" href="#">Purchase Products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Use Products</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="#">Product Sales</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Stock</a>
          </li>
        </ul>
      </div>
<div class="tab-pane fade" id="nav-repo">
        <ul class="nav navbar-ecommerce__menu">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">
              Sales Report
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Today</a>
              <a class="dropdown-item" href="#">Weekly</a>
              <a class="dropdown-item" href="#">Montly</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">All</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">
              Expences Report
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Today</a>
              <a class="dropdown-item" href="#">Weekly</a>
              <a class="dropdown-item" href="#">Montly</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">All</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">
              Ledger Report
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Today</a>
              <a class="dropdown-item" href="#">Weekly</a>
              <a class="dropdown-item" href="#">Montly</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">All</a>
            </div>
          </li>
                    <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">
              Staff Report
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Attendence</a>
              <a class="dropdown-item" href="#">Performence</a>
            </div>
          </li>
        </ul>
      </div>
      <div class="tab-pane fade <?php if($this->uri->segment(1,0)=='management') echo 'show active'; ?>" id="nav-mang">
        <ul class="nav navbar-ecommerce__menu">

          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('management/branches'); ?>">Branches</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('management/users'); ?>">Users</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('management/staff'); ?>">Staff</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('management/services'); ?>">Services</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('management/products'); ?>">Products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('management/packages'); ?>">Packages</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>