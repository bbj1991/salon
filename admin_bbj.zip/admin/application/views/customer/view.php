  
<div class="container-fluid">
  <div class="main-container">
<button class="btn-sm btn-info mt-3 " onclick="mymodal('addstaff');">
            New Customer
    </button> 
   <hr>
<h3>Customer Details</h3>

</div>
</div></div>
</div>

  