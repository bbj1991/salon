  
<div class="container-fluid">
  <div class="main-container">
    <span class="h2">Customer list </span><button class="btn-sm btn-info mt-3 " onclick="mymodal('addcustomer');">
            New Customer
    </button> 
   <hr>

  <div class="container-fluid">
    <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;  $br=$this->db->get_where('customer',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                         <td><?php echo $v->name; ?></td>
                                          <td><?php echo $v->email; ?></td>
                                           <td><?php echo $v->phone; ?></td>
                                        <td><?php  if ($v->status) { ?>
                                          <a class="btn-sm btn-success"  onclick="status(this,'customer',<?php echo $v->id; ?>);">Active
                                                </a>
                                      <?php   }else{?>
                                      <a class="btn-sm btn-warning"  onclick="status(this,'customer',<?php echo $v->id; ?>,1);">InActive
                                                </a>
                                      <?php } ?>
                                              </td>
                                                <td> <a class="btn btn-sm  btn-warning" href="<?php echo base_url('customer/details/'.$v->id); ?>" >Details
                                                </a> 
                                                <a class="btn btn-sm  btn-primary"  onclick="mymodal('editcustomer',<?php echo $v->id; ?>);"  >Edit
                                                </a>
                                                <button type="button" class="btn-sm btn-info btn" onclick="mymodal('addbill',<?php echo $v->id; ?>);">
            New Bill
    </button> <button type="button" class="btn-sm btn-info btn" onclick="mymodal('addappointment',<?php echo $v->id; ?>);">
            New Appointment
    </button> </td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
</div>
</div></div>
</div>

  