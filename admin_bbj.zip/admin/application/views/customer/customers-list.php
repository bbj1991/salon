    
<div class="container-fluid container-fh m-grid">
  <div class="main-container main-container--empty container-fh__content" id="clist" >
    <div class="container-header">
      <h2 class="container-heading">Coustomers</h2>
      <div class="container-header-controls">
        <div class="input-group input-group-icon icon-right container-header-control m-grid__search">
          <input class="form-control search" type="text" placeholder="Search...">
          <span class="input-icon iconfont iconfont-search"></span>
        </div>
        <div class="dropdown container-header-control">
          <a class="btn btn-info" href="#">
            Action
          </a>
        </div>
        <a href="#" class="btn btn-info container-header-control">Create user</a>
      </div>
    </div>
    <div class="m-grid__body">
      <div class="m-grid__body-scrollpane js-scrollable">
        <ul class="m-grid__items list">
          <?php $cus=$this->db->get('cus_services')->result();
          foreach ($cus as $c) { ?>
<li class="m-grid__item" style="width:calc(33% - 20px) !important;     display: inline-grid;">
  <div class="d-flex">
              <img src="img/users/user-5.png" alt="" class="m-grid__item-avatar rounded-circle" width="34" height="34">
              <div class="m-grid__item-info">
                <a href="#" class="m-grid__item-name name">Lori Fisher<?php echo $c->billno; ?></a>
                <span class="m-grid__item-email email">lfisher@example.com</span>
              </div>
            </div>
          </li>
          <?php
           } ?>
          
        </ul>
      </div>
    </div>
    <div class="container-footer">
      <nav>
        <ul class="pagination container-pagination">
        </ul>
      </nav>

      <div class="container-goto-page">
        Go to page: <input type="text" class="form-control container-goto-page__input" value="127"> <span class="container-goto-page__total-amount">for 12345</span>
      </div>
    </div>
  </div>
</div>
</div>

  