  
<div class="container-fluid">
  <div class="main-container">
        <div class="row">
    <div class="col-md-1">
    
    <div class="m-social-profile__nav-avatar" style="width: 100px;
    height: 100px; border: none;">
      <img src="<?php echo base_url(); ?>assets/img/users/user-17.png">

    </div>
    </div>
    <div class="col-md-3 custom-line-height" style="color: #007bff;">
      <span class="font-bold">Name:</span> <span class=" font-semibold"> Raviteja</span><hr>
      <span class="font-bold">Email:</span> <span class=" font-semibold"> raviteja@gmail.com</span>
    </div>
     <div class="col-md-3 custom-line-height" style="color: #007bff;">
      <span class="font-bold">Phone:</span> <span class=" font-semibold"> 9992225525</span><hr>
      <span class="font-bold">Alternet Phone:</span> <span class=" font-semibold"> 8882225356</span>
    </div>
          <div class="col-md-3 custom-line-height" style="color: #007bff;">
      <span class="font-bold">Address  :<br></span> <span class=" font-semibold"> #21 @2333, hsjsjssjjj, gggsgs,Bangalore .</span>
    </div>
    <div class="col-md-2">
     <div class="mt-4 pull-right">
          <span style="font-weight: 600;">Due:</span><span  class="badge badge-sm badge-danger badge-rounded mb-3 mr-3 pull-right">300</span>
          <a  id="M1" style="display: block;" onclick="$(this).hide(); $('#M2').css('display','block');" class="btn btn-sm btn-info" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">More Details...</a>
           <a style="display:none;" id="M2"  onclick="$(this).hide(); $('#M1').show();" class="btn btn-sm btn-danger" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">Less Details...</a>
     </div>
        </div>
    </div>
<div class="row">
        <div class="col-12">
          <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="tab" href="#tab5" role="tab" aria-controls="home" aria-expanded="true">My services</a>
            </li>
                        <li class="nav-item">
              <a class="nav-link " data-toggle="tab" href="#tab1" role="tab" aria-controls="home" aria-expanded="true">Appointments</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="tab" href="#tab2" role="tab" aria-controls="profile" aria-expanded="false">Bills</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="tab" href="#tab3" role="tab" aria-controls="messages">Payments</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="tab" href="#tab4" role="tab" aria-controls="messages">More Details</a>
            </li>            
          </ul>
          <div class="tab-content">
                        <div class="tab-pane active" id="tab5" role="tabpanel" aria-expanded="true">
              <h4>Services Available</h4>
    <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>bill no</th>
                                        <th>customer</th>
                                        <th>total</th>
                                        <th>date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('cus_services',array('customer',$this->uri->segment(3)))->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                         <td><?php echo $v->billno; ?></td>
                                          <td><?php echo $v->customer; ?></td>
                                           <td><?php echo $v->service; ?></td>
                                        <td><?php echo date("d/ m/ Y",strtotime($v->crdate)); ?></td>
                                        <td></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
            </div>
            <div class="tab-pane " id="tab1" role="tabpanel" aria-expanded="true">
              <h4>Appointments</h4>
    <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>bill no</th>
                                        <th>customer</th>
                                        <th>total</th>
                                        <th>date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('bill',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                         <td><?php echo $v->billid; ?></td>
                                          <td><?php echo $v->customer; ?></td>
                                           <td><?php echo $v->total; ?></td>
                                        <td><?php echo date("d/ m/ Y",strtotime($v->crdate)); ?></td>
                                        <td></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
            </div>
            <div class="tab-pane" id="tab2" role="tabpanel" aria-expanded="false">
              <h4>Bills</h4>
    <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>bill no</th>
                                        <th>customer</th>
                                        <th>total</th>
                                        <th>date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('bill',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                         <td><?php echo $v->billid; ?></td>
                                          <td><?php echo $v->customer; ?></td>
                                           <td><?php echo $v->total; ?></td>
                                        <td><?php echo date("d/ m/ Y",strtotime($v->crdate)); ?></td>
                                        <td></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
            </div>
            <div class="tab-pane" id="tab3" role="tabpanel">
              <h3>Payments</h3>
    <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>bill no</th>
                                        <th>customer</th>
                                        <th>total</th>
                                        <th>date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('bill',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                         <td><?php echo $v->billid; ?></td>
                                          <td><?php echo $v->customer; ?></td>
                                           <td><?php echo $v->total; ?></td>
                                        <td><?php echo date("d/ m/ Y",strtotime($v->crdate)); ?></td>
                                        <td></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
            </div>
            <div class="tab-pane" id="tab4" role="tabpanel">
              other details
            </div>
          </div>
        </div>
</div>
</div>
</div></div>
</div>
