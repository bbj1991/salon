  
<div class="container-fluid">
  <div class="main-container">
    <span class="h2">Enquiries list </span><button class="btn-sm btn-info mt-3 " onclick="mymodal('addenquiry');">
            New Enquiry
    </button> 
   <hr>

  <div class="container-fluid">
    <div class="m-datatable">
    <table  class="DT table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $a=1;
                                        $br=$this->db->get_where('enquiry',array())->result();
                                        foreach ($br as $v) {
                                             ?>
                                    <tr>
                                    <td><?php echo $a++; ?></td>
                                         <td><?php echo $v->name; ?></td>
                                          <td><?php echo $v->email; ?></td>
                                           <td><?php echo $v->phone; ?></td>
                                        <td><?php  if ($v->status) { ?>
                                          <a class="btn-sm btn-success"  onclick="status(this,'enquiry',<?php echo $v->id; ?>);">Active
                                                </a>
                                      <?php   }else{?>
                                      <a class="btn-sm btn-warning"  onclick="status(this,'enquiry',<?php echo $v->id; ?>,1);">InActive
                                                </a>
                                      <?php } ?>
                                              </td>
                                                <td> <a class="btn btn-sm  btn-warning" onclick="mymodal('viewenquiry',<?php echo $v->id; ?>);" >View
                                                </a> 
                                                <a class="btn btn-sm  btn-primary"  onclick="mymodal('editenquiry',<?php echo $v->id; ?>);"  >Edit
                                                </a></td>
                                    </tr>

                                            <?php } ?>
                                </tbody>
                                    
                                </table>
  </div>
</div>
</div></div>
</div>

  