<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

   public function index()
	{
		$this->fun->page('products/dashboard');				
	}
	public function purchase()
	{
		$this->fun->page('products/purchase');				
	}
	public function used()
	{
		$this->fun->page('products/used');				
	}
	public function sales()
	{
		$this->fun->page('products/sales');				
	}
	  public function stock()
	{
		$this->fun->page('products/stock');				
	}
}
