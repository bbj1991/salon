<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staff extends CI_Controller {

   public function index()
	{
		$this->fun->page('staff/dashboard');				
	}
	public function details()
	{
		$this->fun->page('staff/details');				
	}
	  public function attendence()
	{
		$this->fun->page('staff/attendence');				
	}
}
