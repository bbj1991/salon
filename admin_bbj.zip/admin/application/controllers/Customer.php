<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

 public function __construct() {
        parent::__construct();
        $this->load->model('mcustomer','mc');
        $this->mc->call();
    }
   public function index()
	{
		$this->fun->page('customer/customers');				
	}
	  public function getview($id)
	{
	$c=$this->db->get_where('customer',array('id'=>$id))->row();  ?>
	
	<div class="d-flex">

              <img src="<?php echo base_url('assets/upload/customer/').$c->photo; ?>" alt="" class="m-grid__item-avatar"  height="75px">
              <div class="m-grid__item-info">
                <a href="#" class="m-grid__item-name">Name : <?php echo $c->name; ?> </a>
                <a href="#" class="m-grid__item-name">Phone : <?php echo $c->phone; ?> </a>

                <span class="m-grid__item-email"> Email : <?php echo $c->email; ?> </span>
            </div> <div class="m-grid__item-info">
                <span class="m-grid__item-email"> Alt phone : <?php echo $c->altphone; ?> </span>
                <span class="m-grid__item-email"> Address : <?php echo $c->address; ?> </span>
              </div>
            </div>			
	<?php }
	  public function details($id)
	{ if (!$id) { redirect('customer','refresh');	}
		$this->fun->page('customer/details');				
	}
	  public function search()
	{
		$this->fun->page('customer/search');				
	}
	  public function view()
	{		
		$this->fun->page('customer/view');				
	}
	  public function appointments()
	{
		$this->fun->page('customer/appointments');			
	} 
	 public function bills()
	{ 
		$this->fun->page('customer/bills');				
	} 
	 public function payments()
	{
		$this->fun->page('customer/payments');				
	}
		 public function enquiries()
	{
		$this->fun->page('customer/enquiries');			
	}
			 public function getservice($id,$qty=1)
	{	
		$s=$this->db->get_where('service',array('id'=>$id))->row();
		?><tr>
              <td><?php echo $s->name; ?>
              	<input type="hidden" name="data[services][<?php echo $s->id; ?>][name]" value="<?php echo $s->name; ?>" class="snames">
              </td>
              <td><?php echo $qty; ?>
              	<input type="hidden" id="srv<?php echo $s->id; ?>" name="data[services][<?php echo $s->id; ?>][qty]" value="<?php echo $qty; ?>" class="sqty">
              </td>
              <td><?php echo $s->price; ?><input type="hidden" name="data[services][<?php echo $s->id; ?>][price]" value="<?php echo $s->price; ?>" class="sprices"></td>
              <td><?php echo $s->price*$qty; ?>	<input type="hidden" name="data[services][<?php echo $s->id; ?>][amount]" value="<?php echo $s->price*$qty; ?>" class="samts"><a class="btn btn-danger" onclick="$(this).parent().parent().remove(); total();" style="float: right;" >Remove</a></td>
            </tr>
		<?php
	}
	 public function getproduct($id,$qty=1)
	{	
		$s=$this->db->get_where('product',array('id'=>$id))->row();
		?><tr>
              <td><?php echo $s->name; ?>
              	<input type="hidden" name="data[products][<?php echo $s->id; ?>][name]" value="<?php echo $s->name; ?>" class="pnames">
              </td>
              <td><?php echo $qty; ?>
              	<input type="hidden" id="prd<?php echo $s->id; ?>" name="data[products][<?php echo $s->id; ?>][qty]" value="<?php echo $qty; ?>" class="pqty">
              </td>
              <td><?php echo $s->price; ?><input type="hidden" name="data[products][<?php echo $s->id; ?>][price]" value="<?php echo $s->price; ?>" class="pprices"></td>
              <td><?php echo $s->price*$qty; ?>	<input type="hidden" name="data[products][<?php echo $s->id; ?>][amount]" value="<?php echo $s->price*$qty; ?>" class="pamts"><a class="btn btn-danger" onclick="$(this).parent().parent().remove(); total();" style="float: right;" >Remove</a></td>
            </tr>
		<?php
	}
 public function getpackage($id,$qty=1)
	{	
		$s=$this->db->get_where('package',array('id'=>$id))->row();
		?><tr>
              <td><?php echo $s->name; ?>
              	<input type="hidden" name="data[packages][<?php echo $s->id; ?>][name]" value="<?php echo $s->name; ?>" class="pknames">
              </td>
              <td><?php echo $qty; ?>
              	<input type="hidden" id="pkg<?php echo $s->id; ?>" name="data[packages][<?php echo $s->id; ?>][qty]" value="<?php echo $qty; ?>" class="pkqty">
              </td>
              <td><?php echo $s->price; ?><input type="hidden" name="data[packages][<?php echo $s->id; ?>][price]" value="<?php echo $s->price; ?>" class="pkprices"></td>
              <td><?php echo $s->price*$qty; ?>	<input type="hidden" name="data[packages][<?php echo $s->id; ?>][amount]" value="<?php echo $s->price*$qty; ?>" class="pkamts"><a class="btn btn-danger" onclick="$(this).parent().parent().remove();total();">Remove</a></td>
            </tr>
		<?php
	}

}
