<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts extends CI_Controller {

   public function index()
	{
		$this->fun->page('accounts/dashboard');				
	}
	  public function expences()
	{
		$this->fun->page('accounts/expences');				
	}
	  public function salaries()
	{		
		$this->fun->page('accounts/salaries');				
	}
	 
}
