<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Management extends CI_Controller {

 public function __construct() {
        parent::__construct();
        $this->load->model('mmanagement','mm');
        $this->mm->call();
    }

   public function branches()
	{
		$this->fun->page('main/branches');				
	}
	  public function users()
	{
		$this->fun->page('main/users');				
	}
	  public function staff()
	{
		$this->fun->page('main/staff');				
	}
	  public function services()
	{
		$this->fun->page('main/services');				
	} 
	 public function products()
	{
		$this->fun->page('main/products');				
	} 
	 public function packages()
	{
		$this->fun->page('main/packages');				
	}

	public function modal()
	{  
		$this->load->view("modals/".$_POST['page'],array('id'=>$_POST['id']));	
		$this->load->view("style1/foot");			
	}
	 public function status()
	{
	  //make sure it is ajax 
		if (1) {
			extract($_POST);
  $this->bbj->table($t);
			if($this->bbj->update(array('status'=>$status),array('id'=>$id))){
				if ($status) {
					echo "1";
				}else{ echo "2";}
					//$this->session->set_userdata('SMSG','sucessfully Updated Location');
				}
			}else{
echo "-1";
			}
		}	

}
