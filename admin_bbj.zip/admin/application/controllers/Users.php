<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {


	public function add()
	{
		$this->load->model('emp');
		$this->emp->user();
		$this->fun->page('users/add');				
	}

	public function list()
	{
		$this->fun->page('users/list');				
	}


	public function edit($id)
	{
		$this->load->model('emp');
		$this->emp->user_update($id);
		if($id){
			 $row=$this->db->get_where('admin',array('id'=>$id))->row();
			 if ($row->id) {
			 }else{
			redirect("users/list");
			 }
		}else{
			redirect("users/list");
			 }
		$this->fun->page('users/edit',array('row'=>$row));				
	}
	public function view($id)
	{
		if($id){
			 $row=$this->db->get_where('admin',array('id'=>$id))->row();
			 if ($row->id) {
			 }else{
			redirect("users/list");
			 }
		}else{
			redirect("users/list");
			 }
		$this->fun->page('users/view',array('row'=>$row));				
	}
		public function delete($id)
	{
		if($id){
			 $row=$this->db->get_where('admin',array('id'=>$id))->row();
			 if ($row->id) {
			 	
			 		if($this->db->delete('admin',array('id'=>$id))){
				
				$this->session->set_userdata('SMSG','sucessfully deleted');
				//echo "success";
			}else{
				$this->session->set_userdata('EMSG','something went wrong please try again');

			}

			 }else{
				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}else{
				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			redirect("users/list");			
	}
}
