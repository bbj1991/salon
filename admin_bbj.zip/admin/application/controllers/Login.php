<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {


	public function index()
	{
		if(isset($_POST['submit'])){
			$this->load->model('modellogin');
			$this->modellogin->checklogin();
		}
		$this->load->view('login');
    }
	public function dashboard()
	{
		$this->fun->page();		
	}
	public function logout()
{
    $user_data = $this->session->all_userdata();
        foreach ($user_data as $key => $value) {
            if ($key != 'session_id' && $key != 'ip_address' && $key != 'user_agent' && $key != 'last_activity') {
                $this->session->unset_userdata($key);
            }
        }
   // $this->session->sess_destroy();
    $this->session->set_userdata('SMSG','Sucessfully Loged Out');
    redirect('login');
}


	}
