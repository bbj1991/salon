      <div class="right_col" role="main">
        <div class="">

          
          <div class="clearfix"></div>
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Employee List <small></small></h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                      <a href="<?php echo base_url()?>assets/#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="<?php echo base_url()?>#">Settings 1</a>
                        </li>
                        <li><a href="<?php echo base_url()?>#">Settings 2</a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
              <div class="x_panel">
               
                <div class="x_content">
                 
                  <table id="datatable-buttons" class="table table-striped table-bordered">
                    <thead>
                      <tr>
                        <th>Name</th>
                      </tr>
                    </thead>


                    <tbody> 
                    <?php 
                    foreach ($this->db->get('plots')->result() as $v) { ?>
                      <tr>
                       <td><?php echo $v->number; ?></td>
                      </tr>
                    <?php }
                    ?>
                       
                      </tbody>
                  </table>
                </div>
              </div>
            </div>
              </div>
            </div>
          </div>

          
        <!-- /page content -->