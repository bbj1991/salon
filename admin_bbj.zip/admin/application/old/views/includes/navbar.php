<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">

          <div class="navbar nav_title" style="border: 0;">
            <a href="index.html" class="site_title"> <img src="<?php echo base_url()?>assets/images/shath_2.jpg"></a>
          </div>
          <div class="clearfix"></div>

          <!-- menu prile quick info -->
          <div class="profile">
            <div class="profile_pic">
              <img src="<?php echo base_url()?>assets/images/shath.jpg" alt="..." class="img-circle profile_img">
            </div>
            <div class="profile_info">
              <span>Welcome To</span>
              
            </div>
          </div>
          <!-- /menu prile quick info -->

          <br />

          <!-- sidebar menu -->
           <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>Shathabdhi Township</h3>
                <ul class="nav side-menu">
                  <li><a href="index.html"><i class="fa fa-home"></i> Home Dashboard</a>
                  
                  </li>
                   <li><a><i class="fa fa-edit"></i> Users <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="form.html">Create User</a></li>
                    <li><a href="existingusers.html">Existing Users</a></li>
                      
                    </ul>
                  </li>
                  <li><a><i class="fa fa-desktop"></i> Projects <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                     <li><a href="createnewproject.html">Create Plot</a></li>
                      <li><a href="existingprojects.html">Existing Plots</a></li>
                      <li><a href="enterproject.html">Create Project</a></li>
                      <li><a href="existingprojects.html">Existing Projects</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-table"></i> Reports <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="reportsprojects.html">Project Reports</a></li>
                    <li><a href="reportcommision.html">Commision Report</a></li>
                    
                    </ul>
                  </li>
                  <li><a><i class="fa fa-table"></i> Bookings <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="enterbooking.html">Enter Bookings</a></li>
                    <li><a href="approveplots.html">Approve Plots</a></li>
                     <li><a href="pendingplots.html">Pending Plots</a></li>
                     <li><a href="bookedplots.html">Booked Plots</a></li>                   
                    </ul>
                  </li>
                  <li><a><i class="fa fa-bar-chart-o"></i> Roles <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="createrole.html">Crerate Role</a></li>
                    <li><a href="existingroles.html">Existing Roles</a></li>
                      
                    </ul>
                  </li>
                  <li><a><i class="fa fa-clone"></i>Payments <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="advancepayment.html">Advance Payment</a></li>  
                    <li><a href="searchadvanced.html">Search Advanced</a></li>                 
                    <li><a href="cancelpayment.html">Cancel Payments</a></li>
                    <li><a href="searchcanceled.html">Search Canceled</a></li>
                    <li><a href="landpayment.html">Lands Payments</a></li>
                    <li><a href="searchlandspayment.html">Search Lands</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-clone"></i>Passbooks <span class="fa fa-chevron-down"></span></a>
                   <ul class="nav child_menu">
                   <li><a href="enterpassbook.html">Enter Passbook</a></li>
                   <li><a href="transferpassbook.html">Transfer Passbook</a></li>
                   <li><a href="existingpassbooks.html">Existing Passbooks</a></li>
                     
                    </ul>
                    </li>
                    <li><a><i class="fa fa-clone"></i>STL More<span class="fa fa-chevron-down"></span></a>
                   <ul class="nav child_menu">
                  <li><a href="entertodo.html">Enter To Do List</a></li>
                   <li><a href="enteractivity.html">Enter Activities</a></li>
                    <li><a href="todolist.html">To Do List</a></li>
                   <li><a href="recent.html">Recent Activities</a></li>
                    </ul>
                    </li>
                </ul>
              </div>            

            </div>
          <!-- /sidebar menu -->

          <div class="sidebar-footer hidden-small">
            <a data-toggle="tooltip" data-placement="top" title="Settings">
              <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
            </a>
            <a data-toggle="tooltip" data-placement="top" title="FullScreen">
              <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
            </a>
            <a data-toggle="tooltip" data-placement="top" title="Lock">
              <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
            </a>
            <a data-toggle="tooltip" data-placement="top" title="Logout">
              <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
            </a>
          </div>
          <!-- /menu footer buttons -->
        </div>
      </div>

      