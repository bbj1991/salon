<div class="right_col" role="main">

        <!-- top tiles -->
        <div class="row tile_count">
          <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
              <span class="count_top"><i class="fa fa-user"></i> Total Users</span>
              <div class="count blue">2,500</div>
              <span class="count_bottom"><i class="blue">4% </i> From last Week</span>
            </div>
          </div>
          <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
              <span class="count_top"><i class="fa fa-clock-o"></i> Total Projects</span>
              <div class="count orr">1,235</div>
              <span class="count_bottom"><i class="orr"><i class="fa fa-sort-asc"></i>3% </i> From last Week</span>
            </div>
          </div>
          <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
              <span class="count_top"><i class="fa fa-user"></i> Booked Projects</span>
              <div class="count green">2,500</div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
            </div>
          </div>
          <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
              <span class="count_top"><i class="fa fa-user"></i> Pending Bookings</span>
              <div class="count red">4,568</div>
              <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>12% </i> From last Week</span>
            </div>
          </div>
          <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
              <span class="count_top"><i class="fa fa-user"></i> Total Collections</span>
              <div class="count yell">2,315</div>
              <span class="count_bottom"><i class="yell"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
            </div>
          </div>
          <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
              <span class="count_top"><i class="fa fa-user"></i> Total Connections</span>
              <div class="count black">8,325</div>
              <span class="count_bottom"><i class="black"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
            </div>
          </div>

        </div>
        <!-- /top tiles -->

        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="dashboard_graph">

              <div class="row x_title">
                <div class="col-md-6">
                  <h3>Total Projects Details <small>Graphical Representaion By Venture</small></h3>
                </div>
                 <div class="col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group pdngh">                                    
                                    <select name="jrquali" class="form-control">
                                        <option>Select Venture</option>
                                        <option value="B.Tech">Suvidha</option>
                                        <option value="M.Tech">Sampadha</option>                                        
                                        <option value="MBA">Magadha</option>
                                        <option value="MBA">Vasudha </option>
                                        <option value="MBA">SV Extension</option>
                                        <option value="MBA">Suvidha Grand</option>
                                        <option value="MBA">Vasudha Extension</option>
                                        
                                    </select>
                                </div> 
                                 </div>
                <div class="col-md-4">
                  <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                    <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
                    <span>December 30, 2014 - January 28, 2015</span> <b class="caret"></b>
                  </div>
                </div>
              </div>

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div id="placeholder33" style="height: 260px; display: none" class="demo-placeholder"></div>
                <div style="width: 100%;">
                  <div id="canvas_dahs" class="demo-placeholder" style="width: 100%; height:270px;"></div>
                </div>
              </div>
              

              <div class="clearfix"></div>
            </div>
          </div>

        </div>
        <br />

      
           

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Shathabdhi Township Admin By<a href="">Techno IT Services</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
      <!-- /page content -->
    </div>

  </div>
