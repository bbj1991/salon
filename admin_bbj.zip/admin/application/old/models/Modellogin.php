<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Modellogin extends CI_Model {

	public function checklogin()
	{
		extract($_POST);
		$data = array('email' => $username, 
			'password'=>md5($password),
			
			);

		$res=$this->db->get_where('adminusers', $data);

		//$res=$this->db->query("select email, password, level from adminusers where email='$email and password='$password' and level='$level'");
		//print_r($res->num_rows());
		if(@$res->num_rows()==1){
		$user=$res->row();
		//$row = array('login' => $user,'level'=>$data['level']);
		$row = array('login' => $user,);
		$this->session->set_userdata($row);
		//$this->session->set_flashdata('loginsucess', 'Suceessfully loggedin');
		redirect('index11', 'refresh');

		}
	
	}
}