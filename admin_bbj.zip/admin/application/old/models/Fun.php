<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fun extends CI_Model {

public function user_photo($mid){
$config['upload_path'] = 'assets/upload/';
$config['file_name'] = 'photo'.$mid.'.jpg';
$config['allowed_types'] = 'gif|jpg|png';
//$config['max_size']     = '1000';
//$config['max_width'] = '1024';
//$config['max_height'] = '768';
$config['overwrite'] = TRUE;
$this->load->library('upload', $config);

// Alternately you can set preferences by calling the ``initialize()`` method. Useful if you auto-load the class:
$this->upload->initialize($config);
if($this->upload->do_upload('photo')){
//messege
	//echo "photo uploaded";
	$this->session->set_flashdata('photomsg', 'Suceessfully photoupload');
}else{
//message
	$a=$this->upload->display_errors('<p>', '</p>');
var_dump($a);
	$this->session->set_flashdata('photomsgerror', 'Suceessfully loggedin');
}

}


public function user_photos($mid){
//print_r($_FILES);
$uphotos= $files = array();
foreach ($_FILES['myphotos'] as $k1 => $v1) {
	//print_r($v);
	foreach ($_FILES['myphotos'][$k1] as $k => $v) {
	$files[$k][$k1]=$v;

	}

}
//print_r($files);
foreach ($files as $v) {
	$_FILES['userfile']=$v;
$filename='user_photo'.$mid.rand().rand().'.jpg';

$config['upload_path'] = 'assets/upload';
$config['file_name'] = $filename;
$config['allowed_types'] = 'gif|jpg|png';
$config['overwrite'] = TRUE;
$this->load->library('upload', $config);

// Alternately you can set preferences by calling the ``initialize()`` method. Useful if you auto-load the class:
//print_r($_FILES['userfile']);
$this->upload->initialize($config);
if($this->upload->do_upload()){
	$data = array(
		'image'=>$filename ,
'maxid'=>$mid,
'status'=>'1'
		 );
	if ($this->db->insert('gallery',$data)) {
		$uphotos[]=$filename;
	}
//messege
	//echo "photo uploaded";
	//$this->session->set_flashdata('photomsg', 'Suceessfully photoupload');
}else{
//message
	
	print_r($this->upload->display_errors());
	echo $this->upload->display_errors('<p>', '</p>');
	$this->session->set_flashdata('photomsgerror', 'Suceessfully loggedin');
}
}

//print_r($uphotos);

}


}