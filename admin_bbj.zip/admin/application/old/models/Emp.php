<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Emp extends CI_Model {

	
 public function __construct() {

        parent::__construct();
    }


		public function addemp()
	{
        $this->bbj->table('employes');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$maxid=$data['role'].rand().rand();
$data['maxid']=$maxid;
			if($this->bbj->add($data)){
				$this->fun->user_photo($maxid);
				echo "success";
			}else{

				echo "failure";
			}
		}

	}

		public function branch()
	{

        $this->bbj->table('branches');
		print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
			if($this->bbj->add($data)){
				echo "success";
			}else{

				echo "failure";
			}
		}

	}
		public function venture()
	{

        $this->bbj->table('ventures');
		print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$maxid='VE'.rand().rand();
$data['maxid']=$maxid;
			if($this->bbj->add($data)){
				$this->fun->user_photo($maxid);
				echo "success";
			}else{

				echo "failure";
			}
		}

	}
	public function addplot()
	{

        $this->bbj->table('plots');
		print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$maxid='P'.rand().rand();
$data['maxid']=$maxid;
$data['slabdetails']=json_encode($slab);
			if($this->bbj->add($data)){
				$this->fun->user_photo($maxid);
				echo "success";
			}else{

				echo "failure";
			}
		}

	}

}