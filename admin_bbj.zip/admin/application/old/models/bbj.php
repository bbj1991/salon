<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bbj extends CI_Model {

    public $table;

	 	public function table($t)
	{
		$this->table=$t;
		//$this->db->select($t);
	}
		public function add($data)
	{	
		@$data['ip']=$_SERVER['REMOTE_ADDR'];
		@$data['crby']="BBj";
		@$data['crdate']=date("Y-m-d H:i:s");
		@$data['upby']="BBj";
		@$data['updates']=date("Y-m-d H:i:s");
		return $this->db->insert($this->table,$data);
	}
		public function update($data,$w)
	{
		$data->upby="BBj";
		$data->update=date("Y-m-d H:i:s");

		return $this->db->update($this->table,$data,$w);
	}

		public function all()
	{
		return $this->db->get()->result();
	}

		public function get($w)
	{
		return $this->db->where($w)->get($this->table)->result();
	}

		public function row($id,$f='id')
	{

		return $this->db->get_where($this->table,array($f=>$id))->row();
	}
		public function getfv($a,$id,$f='id')
	{

		return $this->db->get_where($this->table,array($f=>$id))->row()->$a;
	}

}