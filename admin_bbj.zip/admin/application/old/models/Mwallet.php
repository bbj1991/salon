<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mwallet extends CI_Model {

 
	public function add($data)
	{	
		@$data['ip']=$_SERVER['REMOTE_ADDR'];
		@$data['crby']="BBj";
		@$data['crdate']=date("Y-m-d H:i:s");
		@$data['maxid']='S4E-TXN-'.$data['from'].'-'.time().rand();
		@$data['status']=1;
		return $this->db->insert('statements',$data);
	}
	public function purchase()
	{
		$orderdetails=array('orderid'=>6789768,'pid'=>789,'price'=>900);
		$details=json_encode($orderdetails);
		$p = array('type' =>'credit' ,
		'st_type'=>'productpurchase',
		'msg'=>"product purshaed by you",
		'amount'=>900,
		'details'=>$details,
		'from'=>'s4e12345',
		'to'=>'s4e12345'
		 );
		return $this->add($p);

	}

}