<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fun extends CI_Model {

public function __construct()
{
	parent::__construct();

}
	public function create_exam()
	{
		//$this->session->sess_destroy();
		if(!$this->session->userdata('exam')){
$limit=5;
	//echo "start";
		$crdate=date('Y-m-d h:i:s');
		$t=strtotime($crdate)-1494746590;
		$examid='OT_EXAM_'.rand(10000,99999).$t;
		extract($this->session->userdata());
		$q=$this->db->order_by('id', 'RANDOM')->limit($limit,0)->get_where('questions',array('courses'=>$course,'level'=>$type))->result();
		$question=json_encode($q);
$exam = array('examid' =>$examid, 'crdate'=>$crdate, 'course'=>$course, 'type'=>$type, 'user'=>$name, 'email'=>$email, 'phone'=>$phone,'question'=>$question, 'status'=>0 );
if($this->db->insert('exam', $exam)){
	//$this->session->sess_destroy();
	foreach ($this->session->userdata() as $k=>$v) {
$this->session->unset_userdata($k);	}
	
	$this->session->set_userdata('exam',$exam);
	foreach ($q as $k => $v) {
		$qs[]=$k;
		$qd[$k]=$v;
		$rns[$k]=$v->answer;
		$uns[$k]='';

	}
	$this->session->set_userdata('qs',$qs);
	$this->session->set_userdata('qd',$qd);
	$this->session->set_userdata('rns',$rns);
	$this->session->set_userdata('uns',$uns);
	$this->session->set_userdata('cqid',0);

}
	}
	}

	public function chkexam()
	 {

	 	if ($this->session->userdata('exam')) {
	 		redirect('welcome/start');
	 	}
	 } 

}

	 ?>