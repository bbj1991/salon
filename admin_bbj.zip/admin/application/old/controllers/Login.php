<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {



		public function bharath()
	{
		echo "busy";
		$this->load->view('login');
		
		}
		public function mahi()
	{
		echo "sleepy";
		}
		public function pavi()
	{
		echo "Hello",$this->uri->segment(1);
		//$this->load->view('login');
		
		}
	public function index()
	{
		if(isset($_POST['submit'])){
			$this->load->model('modellogin');
			$this->modellogin->checklogin();
		}
		$this->load->view('login');
		
		}


	}
