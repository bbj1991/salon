<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function star1()
	{
	function test2($b,$t)
	{
		$a=$t->db->get_where('star1',array('status'=>0,'maxid'=>''))->row()->id;
		//echo $a;
		//echo $t->db->last_query();
$t->db->update('star1',array('maxid'=>$a.'bbj'.rand(),'status'=>1),array('id'=>$a));
for ($i=0; $i <3 ; $i++) { 
	$t->db->insert('star1',array('pid'=>$a,'status'=>0));
}
	
	}
		
		for ($i=0; $i <100 ; $i++) { 
			test2($i,$this);
		}
	
	}
		public function star2()
	{
	function test2($b,$t)
	{
		$a=$t->db->get_where('star2',array('status'=>0,'maxid'=>''))->row()->id;
		//echo $a;
		//echo $t->db->last_query();
$t->db->update('star2',array('maxid'=>$a.'bbj'.rand(),'status'=>1),array('id'=>$a));
for ($i=0; $i <5 ; $i++) { 
	$t->db->insert('star2',array('pid'=>$a,'status'=>0));
}
	
	}
		
		for ($i=0; $i <100 ; $i++) { 
			test2($i,$this);
		}
	
	}
		public function star3()
	{
	function test2($b,$t)
	{
		$a=$t->db->get_where('star3',array('status'=>0,'maxid'=>''))->row()->id;
		//echo $a;
		//echo $t->db->last_query();
$t->db->update('star3',array('maxid'=>$a.'bbj'.rand(),'status'=>1),array('id'=>$a));
for ($i=0; $i <5 ; $i++) { 
	$t->db->insert('star3',array('pid'=>$a,'status'=>0));
}
	
	}
		
		for ($i=0; $i <100 ; $i++) { 
			test2($i,$this);
		}
	
	}
		public function star4()
	{
	function test2($b,$t)
	{
		$a=$t->db->get_where('star4',array('status'=>0,'maxid'=>''))->row()->id;
		//echo $a;
		//echo $t->db->last_query();
$t->db->update('star4',array('maxid'=>$a.'bbj'.rand(),'status'=>1),array('id'=>$a));
for ($i=0; $i <7 ; $i++) { 
	$t->db->insert('star4',array('pid'=>$a,'status'=>0));
}
	
	}
		
		for ($i=0; $i <100 ; $i++) { 
			test2($i,$this);
		}
	
	}

	public function purchase()
	{
		$this->load->model('Mwallet');
		for ($i=0; $i <1000 ; $i++) { 
			
		$this->Mwallet->purchase();
		}
		echo "test done";
	}
	public function test()
	{
	function test2($b,$t)
	{
		$a=$t->db->order_by('id','RANDOM')->get('test')->row()->id;
		//echo $t->db->last_query();
		$t->db->insert('test',array('pid'=>$a,'name'=>'bbj-'.$b.' '.rand()));
	}
		
		for ($i=0; $i <100000 ; $i++) { 
			test2($i,$this);
		}
	
	}

		public function standard($a)
	{
	
		//$a=$this->db->order_by('id','RANDOM')->get_where('test',array('act'=>0))->row()->id;
		//$a=1917;
		//echo $t->db->last_query();
		$this->db->update('test',array('act'=>1),array('id'=>$a));

		$l=$this->getlevels($a);
		print_r($l);
		foreach ($l as $k => $v) {

if(!$v){
	break;
}

	if (@$this->db->get_where('test',array('act'=>0,'id'=>$v))->row()->id) {
		
			echo "</br>no comission given to $v at $k level for stndard refferal because in active</br>";
	}else{
if($k=='l3'){	echo "</br>level 3 comission given and taken by admin to $v at $k level for stndard refferal </br>";
 $c= $this->db->get_where('standard',array('act'=>1,'l3'=>$v))->num_rows();
if($c >=10){
echo 200 ;
}

}else{

			echo "</br>comission given to $v at $k level for stndard refferal </br>";
	}

}


		}
	
	}

		public function getlevels($id)
	{
		return $this->db->select('l1,l2,l3,l4,l5,l6,l6,l7,l8,l9,l10')->get_where('standard',array('id'=>$id))->row();
		//$id=8560;
		// $this->bbj->table('level');
		// $l=$this->bbj->row($id);
		// print_r($l);
// $l=array($id);
// 		@$l[1]=$l1=$this->bbj->row($id)->pid;
// 		@$l[2]=$l2=$this->bbj->row($l1)->pid;
// 		@$l[3]=$l3=$this->bbj->row($l2)->pid;
// 		@$l[4]=$l4=$this->bbj->row($l3)->pid;
// 		@$l[5]=$l5=$this->bbj->row($l4)->pid;
// 		@$l[6]=$l6=$this->bbj->row($l5)->pid;
// 		@$l[7]=$l7=$this->bbj->row($l6)->pid;
// 		@$l[8]=$l8=$this->bbj->row($l7)->pid;
// 		@$l[9]=$l9=$this->bbj->row($l8)->pid;
// 		@$l[10]=$l10=$this->bbj->row($l9)->pid;
 //return $l;
		
	}



	public function level($id,$p,$cp)
	{
		//$id=8560;
$c =array(20,15,10,5,3,2,2,1,1,.5,.5);
		$this->bbj->table('test');
$l=array($id);
		@$l[1]=$l1=$this->bbj->row($id)->pid;
		@$l[2]=$l2=$this->bbj->row($l1)->pid;
		@$l[3]=$l3=$this->bbj->row($l2)->pid;
		@$l[4]=$l4=$this->bbj->row($l3)->pid;
		@$l[5]=$l5=$this->bbj->row($l4)->pid;
		@$l[6]=$l6=$this->bbj->row($l5)->pid;
		@$l[7]=$l7=$this->bbj->row($l6)->pid;
		@$l[8]=$l8=$this->bbj->row($l7)->pid;
		@$l[9]=$l9=$this->bbj->row($l8)->pid;
		@$l[10]=$l10=$this->bbj->row($l9)->pid;
		print_r($l);
echo $tc=$cp*$p/100;
		foreach ($l as $k => $v) {
if(!$v){
	break;
}

			$bh=$c[$k];
$s=$bh*$tc/100;

			echo "</br>comission shared to $v at $k level is $s </br>";
		}
		
	}

	public function addplot()
	{
		$this->load->model('emp');
		$this->emp->addplot();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/addplot');		
		$this->load->view('includes/foot');				
	}


	public function addstaff()
	{
		$this->load->model('emp');
		$this->emp->addemp();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/addemp');		
		$this->load->view('includes/foot');				
	}

	public function addsgm()
	{
		$this->load->model('emp');
		$this->emp->addemp();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/sgm');		
		$this->load->view('includes/foot');				
	}

	public function addgm()
	{
		$this->load->model('emp');
		$this->emp->addemp();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/gm');		
		$this->load->view('includes/foot');				
	}

	public function addagm()
	{
		$this->load->model('emp');
		$this->emp->addemp();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/agm');		
		$this->load->view('includes/foot');				
	}

	public function adddmm()
	{
		$this->load->model('emp');
		$this->emp->addemp();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/dmm');		
		$this->load->view('includes/foot');				
	}


	public function addcmm()
	{
		$this->load->model('emp');
		$this->emp->addemp();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/cmm');		
		$this->load->view('includes/foot');				
	}

	public function addmm()
	{
		$this->load->model('emp');
		$this->emp->addemp();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/mm');		
		$this->load->view('includes/foot');				
	}

	public function addmo()
	{
		$this->load->model('emp');
		$this->emp->addemp();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/mo');		
		$this->load->view('includes/foot');				
	}

	public function addse()
	{
		$this->load->model('emp');
		$this->emp->addemp();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/se');		
		$this->load->view('includes/foot');				
	}






	public function addbranch()
	{
		$this->load->model('emp');
		$this->emp->branch();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/addbranch');		
		$this->load->view('includes/foot');				
	}



	public function addventure()
	{
		$this->load->model('emp');
		$this->emp->venture();
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/addventure');		
		$this->load->view('includes/foot');				
	}

	public function emplist()
	{
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/listemp');		
		$this->load->view('includes/foot');				
	}
		public function venturelist()
	{
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/listventures');		
		$this->load->view('includes/foot');				
	}
		public function plotlist()
	{
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/listplots');		
		$this->load->view('includes/foot');				
	}	public function branchlist()
	{
		$this->load->view('includes/header');
		$this->load->view('includes/topnav');
		$this->load->view('includes/navbar');
		$this->load->view('pages/listbranches');		
		$this->load->view('includes/foot');				
	}

}
