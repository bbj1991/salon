<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

 public function __construct() {

        parent::__construct();

$this->bbj->table('employes');
    }
public function sgm()
	{

$o=$this->bbj->get(array('role'=>'SGM'));
foreach ($o as $v) {?>
<option value="<?php echo $v->maxid; ?>"><?php echo $v->name; ?></option>
<?php }

	}
public function gm($id)
	{

$o=$this->bbj->get(array('sgm'=>$id,'role'=>'GM'));
foreach ($o as $v) {?>
<option value="<?php echo $v->maxid; ?>"><?php echo $v->name; ?></option>
<?php }

	}
	public function agm($id)
	{

$o=$this->bbj->get(array('gm'=>$id,'role'=>'AGM'));
foreach ($o as $v) {?>
<option value="<?php echo $v->maxid; ?>"><?php echo $v->maxid; ?></option>
<?php }

	}
public function dmm($id)
	{

$o=$this->bbj->get(array('agm'=>$id,'role'=>'DMM'));
foreach ($o as $v) {?>
<option value="<?php echo $v->maxid; ?>"><?php echo $v->maxid; ?></option>
<?php }

	}
	public function cmm($id)
	{

$o=$this->bbj->get(array('dmm'=>$id,'role'=>'CMM'));
foreach ($o as $v) {?>
<option value="<?php echo $v->maxid; ?>"><?php echo $v->maxid; ?></option>
<?php }

	}
	public function mm($id)
	{

$o=$this->bbj->get(array('cmm'=>$id,'role'=>'MM'));
foreach ($o as $v) {?>
<option value="<?php echo $v->maxid; ?>"><?php echo $v->maxid; ?></option>
<?php }

	}
	public function mo($id)
	{

$o=$this->bbj->get(array('mm'=>$id,'role'=>'MO'));
foreach ($o as $v) {?>
<option value="<?php echo $v->maxid; ?>"><?php echo $v->maxid; ?></option>
<?php }

	}
	public function se($id)
	{

$o=$this->bbj->get(array('mo'=>$id,'role'=>'se'));
foreach ($o as $v) {?>
<option value="<?php echo $v->maxid; ?>"><?php echo $v->maxid; ?></option>
<?php }

	}
}
