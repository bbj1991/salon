<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Modellogin extends CI_Model {

	public function checklogin()
	{
		extract($_POST);
		$data = array('email' => $username, 
			'password'=>$password
			
			);

		$res=$this->db->get_where('admin', $data)->row();
		if(@$res->id){
		$user=$res;
		$row = array('login' => $user,'ALOGIN'=>'ADMIN');
		$this->session->set_userdata($row);
		$this->session->set_userdata('SMSG','sucessfully loggedin');
		redirect('dashboard', 'refresh');
			}else{
				$res=$this->db->get_where('user', $data)->row();
		if(@$res->id){
		$user=$res;
		$row = array('login' => $user,'ALOGIN'=>'USER');
		$this->session->set_userdata($row);
		$this->session->set_userdata('SMSG','sucessfully loggedin');
		redirect('dashboard', 'refresh');
			}else{
				$this->session->set_userdata('EMSG','Incorrect login details');
			}
			}
	
	}
}