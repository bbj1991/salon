<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Emp extends CI_Model {

	
 public function __construct() {

        parent::__construct();
    }


		
public function addemp()
	{
        $this->bbj->table('employee');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$maxid=$data['role'].rand().rand();
$data['maxid']=$maxid;
$data['image']='photo'.$maxid.'.jpg';
			if($this->bbj->add($data)){
				$this->fun->user_photo($maxid);
				$this->session->set_userdata('SMSG','sucessfully added new employee');
				//echo "success";
			}else{
				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	}
	public function employe()
	{
        $this->bbj->table('employee');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$maxid=$data['role'].rand().rand();
$data['empid']=$maxid;

			if($this->bbj->add($data)){
				
				$this->session->set_userdata('SMSG','sucessfully added new employee');
				//echo "success";
			}else{
				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	}

	 public function employe_update($id)
	{
		$this->bbj->table('employee');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
			if($this->bbj->update($data,array('id'=>$id))){
					$this->session->set_userdata('SMSG','sucessfully Updated Employe Details');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	} 

		public function location()
	{

        $this->bbj->table('locations');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new Location');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	}
	public function location_update($id)
	{

        $this->bbj->table('locations');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
			if($this->bbj->update($data,array('id'=>$id))){
					$this->session->set_userdata('SMSG','sucessfully Updated Location');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	}
				
				public function user()
	{

        $this->bbj->table('admin');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$data['type']='USER';
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new user');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	}
	
	public function user_update($id)
	{
	
        $this->bbj->table('admin');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
			if($this->bbj->update($data,array('id'=>$id))){
					$this->session->set_userdata('SMSG','sucessfully Updated User Details');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}
	
	}

	public function service()
	{

        $this->bbj->table('services');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new Service');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	}

		
		public function services_update($id)
		{
			$this->bbj->table('services');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
			if($this->bbj->update($data,array('id'=>$id))){
					$this->session->set_userdata('SMSG','sucessfully Updated User Details');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}
		}

	public function product()
	{

        $this->bbj->table('products');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new Product');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	}
	public function product_update($id)
	{
		$this->bbj->table('products');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
			if($this->bbj->update($data,array('id'=>$id))){
					$this->session->set_userdata('SMSG','sucessfully Updated User Details');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}
	}
		
	public function Package()
	{

        $this->bbj->table('packages');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$data['services']=implode(',', $data['services']);
$data['products']=implode(',', $data['products']);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new Product');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	}

	public function package_update($id)
	{
		$this->bbj->table('packages');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$data['services']=implode(',', $data['services']);
$data['products']=implode(',', $data['products']);
			if($this->bbj->update($data,array('id'=>$id))){
					$this->session->set_userdata('SMSG','sucessfully Updated User Details');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}
	}

	public function customer()
	{
        $this->bbj->table('customers');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
$maxid=rand().rand();
$data['maxid']=$maxid;
			if($this->bbj->add($data)){
				
				$this->session->set_userdata('SMSG','sucessfully added new customer');
				//echo "success";
			}else{
				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}

	}

	public function customer_update($id)
	{
		$this->bbj->table('customers');
		//print_r($_POST);
		if (isset($_POST['submit'])) {
extract($_POST);
			if($this->bbj->update($data,array('id'=>$id))){
					$this->session->set_userdata('SMSG','sucessfully Updated User Details');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
		}
	}


}