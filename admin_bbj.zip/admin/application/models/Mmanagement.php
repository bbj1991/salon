<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mmanagement extends CI_Model {

	
 public function __construct() {

        parent::__construct();
    }
    public function call()
    {
    	$this->branch();
    	$this->user();
    	$this->staff();
    	$this->category();
    	$this->service();
    	$this->product();
    	$this->package();
    }

		public function branch()
	{

		//print_r($_POST);
		if (isset($_POST['add_branch'])) {

        $this->bbj->table('branch');
extract($_POST);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new Location');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}
			public function user()
	{
		//print_r($_FILES);
		if (isset($_POST['add_user'])) {

        $this->bbj->table('user');
extract($_POST);
$data['status']='1';
$maxid='A'.time().rand();
$data['photo']='photo'.$maxid.'.jpg';
			if($this->bbj->add($data)){
				if ($_FILES['photo']) {
				$this->fun->user_photo($data['photo'],'photo','assets/upload/user/');
				}
					$this->session->set_userdata('SMSG','sucessfully added new User');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}
				public function staff()
	{
		//print_r($_FILES);
		if (isset($_POST['add_staff'])) {

        $this->bbj->table('staff');
extract($_POST);
$data['status']='1';
$maxid='B'.time().rand();
$data['photo']='photo'.$maxid.'.jpg';
$data['idproof']='idproof'.$maxid.'.jpg';
$data['addrproof']='addrproof'.$maxid.'.jpg';
$data['other']='other'.$maxid.'.jpg';
			if($this->bbj->add($data)){
				if ($_FILES['photo']) {
				$this->fun->user_photo($data['photo'],'photo','assets/upload/staff/');
				}
				if ($_FILES['idproof']) {
				$this->fun->user_photo($data['idproof'],'idproof','assets/upload/staff/');
				}
				if ($_FILES['addrproof']) {
				$this->fun->user_photo($data['addrproof'],'addrproof','assets/upload/staff/');
				}
				if ($_FILES['other']) {
				$this->fun->user_photo($data['other'],'other','assets/upload/staff/');
				}
					$this->session->set_userdata('SMSG','sucessfully added new User');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}

		public function category()
	{

		//print_r($_POST);
		if (isset($_POST['add_category'])) {

        $this->bbj->table('category');
extract($_POST);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new category');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}
			public function service()
	{

		//print_r($_POST);
		if (isset($_POST['add_service'])) {

        $this->bbj->table('service');
extract($_POST);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new service');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}
				public function product()
	{

		//print_r($_POST);
		if (isset($_POST['add_product'])) {

        $this->bbj->table('product');
extract($_POST);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new product');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}
				public function package()
	{

		//print_r($_POST);
		if (isset($_POST['add_package'])) {

        $this->bbj->table('package');
       // print_r($_POST);
extract($_POST);
$s=$data['services'];
$s1=array();
foreach ($s['id'] as $k=>$v) {
	$s1[$v]=$s['qty'][$k];
}
$p=$data['products'];
$p1=array();
foreach ($p['id'] as $k=>$v) {
	$p1[$v]=$p['qty'][$k];
}
$data['services']=json_encode($s1);
$data['products']=json_encode($p1);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new package');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}
}