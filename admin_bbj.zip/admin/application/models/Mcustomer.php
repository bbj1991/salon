<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mcustomer extends CI_Model {
	
 public function __construct() {

        parent::__construct();
    }
    public function call()
    {
    	$this->customer();
        $this->enquiry();
         $this->bill();
         $this->appointment();

    }
		
			public function bill()
	{
		//print_r($this->session->userdata('login'));
		if (isset($_POST['add_bill'])) {
$data['products']=array();
$data['services']=array();
$data['packages']=array();
			extract($_POST);
			if ($data['customer']=="NEWUSER") {
$this->bbj->table('customer');
$cdata['status']='1';
$maxid='C'.time().rand();
$cdata['photo']='photo'.$maxid.'.jpg';
			if($this->bbj->add($cdata)){
				if ($_FILES['photo']) {
				$this->fun->user_photo($cdata['photo'],'photo','assets/upload/customer/');
				}
$data['customer']=$this->db->insert_id();
}}
        $this->bbj->table('bill');
$data['status']='1';
$billid='C'.time().rand();
$data['billid']=$billid;
@$data['branch']=$this->session->userdata('login')->branch;
@$data['products']=json_encode($data['products']);
@$data['services']=json_encode($data['services']);
@$data['packages']=json_encode($data['packages']);

if($this->bbj->add($data)){
	extract($_POST['data']);
	if (count(@$services)) {
		foreach ($services as $s => $sa) {
			for ($i=1; $i <=$sa['qty'] ; $i++) { 
$sd = array('billno' =>$billid ,'customer'=>$data['customer'],'service'=>$s,'status'=>1 );
$this->bbj->table('cus_services');
$this->bbj->add($sd);
			}
		}
	}
	if (count(@$packages)) {
		foreach ($packages as $pid => $pa) {
			for ($i=1; $i <=$pa['qty'] ; $i++) { 
				$pk=$this->db->get_where('package',array('id'=>$pid))->row();
				$srv=array();
				if($pk->services){$srv=json_decode($pk->services);}
foreach ($srv as $s => $q) {
			for ($i=1; $i <=$q ; $i++) { 
$sd = array('billno' =>$billid ,'customer'=>$data['customer'],'service'=>$s,'refpackage'=>$pk->id,'expiry'=>$pk->enddate,'status'=>1 );
$this->bbj->table('cus_services');
$this->bbj->add($sd);
			}

			}
		}
	}}
				$this->session->set_userdata('SMSG','sucessfully added new Bill');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}
		
			public function customer()
	{
		//print_r($_FILES);
		if (isset($_POST['add_customer'])) {

        $this->bbj->table('customer');
extract($_POST);
$data['status']='1';
$maxid='C'.time().rand();
$data['photo']='photo'.$maxid.'.jpg';
			if($this->bbj->add($data)){
				if ($_FILES['photo']) {
				$this->fun->user_photo($data['photo'],'photo','assets/upload/customer/');
				}
					$this->session->set_userdata('SMSG','sucessfully added new customer');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}

		public function enquiry()
	{

		//print_r($_POST);
		if (isset($_POST['add_enquiry'])) {

        $this->bbj->table('enquiry');
extract($_POST);
$data['status']='1';
			if($this->bbj->add($data)){
					$this->session->set_userdata('SMSG','sucessfully added new enquiry');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}
			public function appointment()
	{

		//print_r($_POST);
		if (isset($_POST['add_appointment'])) {

        $this->bbj->table('appointment');
extract($_POST);
@$data['branch']=$this->session->userdata('login')->branch;
$data['status']='0';
			if($this->bbj->add($data)){
				$this->db->update('cus_services',array('status'=>2),array('id'=>$data['service']));
					$this->session->set_userdata('SMSG','sucessfully added new Appointment');
			}else{

				$this->session->set_userdata('EMSG','something went wrong please try again');

			}
			//redirect('','refresh');
		}

	}
		
}