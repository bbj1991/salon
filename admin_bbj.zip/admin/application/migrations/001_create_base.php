<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_create_base extends CI_Migration {

	public function up() {

		## Create Table adminusers
		$this->dbforge->add_field("`id` int(11) NOT NULL");
		$this->dbforge->add_field("`crdate` date NOT NULL ");
		$this->dbforge->add_field("`email` varchar(50) NOT NULL ");
		$this->dbforge->add_field("`password` varchar(100) NOT NULL ");
		$this->dbforge->add_field("`level` varchar(10) NOT NULL ");
		$this->dbforge->add_field("`status` enum('0','1') NOT NULL DEFAULT '1' ");
		$this->dbforge->create_table("adminusers", TRUE);
		$this->db->query('ALTER TABLE  `adminusers` ENGINE = InnoDB');
		## Create Table bookings
		$this->dbforge->add_field("`id` int(11) NOT NULL auto_increment");
		$this->dbforge->add_key("id",true);
		$this->dbforge->add_field("`crdate` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`crby` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`updates` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`custmername` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`email` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`phone` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`address` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`altphone` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`photo` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`descp` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`adhadhar` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`stotus` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`maxid` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`ipaddress` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`status` enum('0','1') NOT NULL DEFAULT '1' ");
		$this->dbforge->create_table("bookings", TRUE);
		$this->db->query('ALTER TABLE  `bookings` ENGINE = InnoDB');
		## Create Table branches
		$this->dbforge->add_field("`id` int(11) NOT NULL auto_increment");
		$this->dbforge->add_key("id",true);
		$this->dbforge->add_field("`crdate` varchar(266) NOT NULL ");
		$this->dbforge->add_field("`crby` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`updates` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`name` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`address` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`contactperson` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`email` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`phone` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`ip` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`status` enum('0','1') NOT NULL DEFAULT '1' ");
		$this->dbforge->add_field("`upby` varchar(255) NOT NULL ");
		$this->dbforge->create_table("branches", TRUE);
		$this->db->query('ALTER TABLE  `branches` ENGINE = InnoDB');
		## Create Table employes
		$this->dbforge->add_field("`id` int(11) NOT NULL auto_increment");
		$this->dbforge->add_key("id",true);
		$this->dbforge->add_field("`crby` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`crdate` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`updates` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`name` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`email` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`phone` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`empid` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`designation` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`gender` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`dob` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`doj` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`permnentaddress` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`communcationaddress` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`pan` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`userid` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`maxid` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`role` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`branch` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`photo` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`vp` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`sgm` varchar(50) NOT NULL ");
		$this->dbforge->add_field("`gm` varchar(50) NOT NULL ");
		$this->dbforge->add_field("`agm` varchar(50) NOT NULL ");
		$this->dbforge->add_field("`dmm` varchar(50) NOT NULL ");
		$this->dbforge->add_field("`cmm` varchar(50) NOT NULL ");
		$this->dbforge->add_field("`mm` varchar(50) NOT NULL ");
		$this->dbforge->add_field("`mo` varchar(50) NOT NULL ");
		$this->dbforge->add_field("`ip` varchar(50) NOT NULL ");
		$this->dbforge->add_field("`status` enum('0','1') NOT NULL ");
		$this->dbforge->add_field("`password` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`upby` varchar(255) NOT NULL ");
		$this->dbforge->create_table("employes", TRUE);
		$this->db->query('ALTER TABLE  `employes` ENGINE = InnoDB');
		## Create Table payments
		$this->dbforge->add_field("`id` int(11) NOT NULL auto_increment");
		$this->dbforge->add_key("id",true);
		$this->dbforge->add_field("`crdate` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`crby1` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`updatedee` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`amount` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`passbook` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`recipt details` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`paymenttype` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`ip` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`status` enum('0','1') NULL DEFAULT '1' ");
		$this->dbforge->create_table("payments", TRUE);
		$this->db->query('ALTER TABLE  `payments` ENGINE = InnoDB');
		## Create Table plots
		$this->dbforge->add_field("`id` int(11) NOT NULL ");
		$this->dbforge->add_field("`crby` varchar(20) NOT NULL ");
		$this->dbforge->add_field("`crdate` varchar(20) NOT NULL ");
		$this->dbforge->add_field("`updates` varchar(20) NOT NULL ");
		$this->dbforge->add_field("`number` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`area` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`size` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`facings` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`sno` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`cost` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`allotmentcost` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`details` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`image` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`gallery` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`commisiontype` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`slabdetails` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`venture` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`maxid` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`ip` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`status` enum('0','1') NOT NULL DEFAULT '1' ");
		$this->dbforge->add_field("`upby` varchar(100) NOT NULL ");
		$this->dbforge->create_table("plots", TRUE);
		$this->db->query('ALTER TABLE  `plots` ENGINE = InnoDB');
		## Create Table sessrs
		$this->dbforge->add_field("`id` varchar(128) NOT NULL ");
		$this->dbforge->add_field("`ip_address` varchar(45) NOT NULL ");
		$this->dbforge->add_field("`timestamp` int(10) unsigned NOT NULL ");
		$this->dbforge->add_field("`data` blob NOT NULL ");
		$this->dbforge->create_table("sessrs", TRUE);
		$this->db->query('ALTER TABLE  `sessrs` ENGINE = MyISAM');
		## Create Table ventures
		$this->dbforge->add_field("`id` int(11) NOT NULL auto_increment");
		$this->dbforge->add_key("id",true);
		$this->dbforge->add_field("`crby` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`crdate` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`updates` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`name` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`plots` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`highlights` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`description` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`address` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`image` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`gallery` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`ip` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`status` enum('0','1') NOT NULL DEFAULT '1' ");
		$this->dbforge->add_field("`upby` varchar(255) NOT NULL ");
		$this->dbforge->add_field("`maxid` varchar(255) NOT NULL ");
		$this->dbforge->create_table("ventures", TRUE);
		$this->db->query('ALTER TABLE  `ventures` ENGINE = InnoDB');
	 }

	public function down()	{
		### Drop table adminusers ##
		$this->dbforge->drop_table("adminusers", TRUE);
		### Drop table bookings ##
		$this->dbforge->drop_table("bookings", TRUE);
		### Drop table branches ##
		$this->dbforge->drop_table("branches", TRUE);
		### Drop table employes ##
		$this->dbforge->drop_table("employes", TRUE);
		### Drop table payments ##
		$this->dbforge->drop_table("payments", TRUE);
		### Drop table plots ##
		$this->dbforge->drop_table("plots", TRUE);
		### Drop table sessrs ##
		$this->dbforge->drop_table("sessrs", TRUE);
		### Drop table ventures ##
		$this->dbforge->drop_table("ventures", TRUE);

	}
}